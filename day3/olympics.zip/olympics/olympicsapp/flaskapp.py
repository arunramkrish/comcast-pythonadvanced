from flask import Flask, render_template, request, g
import sqlite3

app = Flask(__name__)
DATABASE = 'database.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

@app.route('/')
def index():
    cur = get_db().cursor()
    cur.execute('SELECT * FROM items')
    items = cur.fetchall()
    return render_template('item_list.html', items=items)

if __name__ == '__main__':
    with app.app_context():
        db = get_db()
        db.execute('''CREATE TABLE IF NOT EXISTS items
                      (id INTEGER PRIMARY KEY AUTOINCREMENT,
                       name TEXT NOT NULL,
                       description TEXT,
                       price REAL NOT NULL)''')
        db.execute('''INSERT INTO ITEMS (name, description, price) VALUES('A1', 'B1', 1000.0)''')
        db.commit()
    app.run(debug=True)

