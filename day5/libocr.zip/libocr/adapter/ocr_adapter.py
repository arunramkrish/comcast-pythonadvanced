from subprocess import check_output
import logging
from libocr.ocr_pdf_to_text_pdf import ocr_pdf
from functools import lru_cache


@lru_cache(maxsize=2)
def finstinct_ocr(filename, input_config=None, use_cache=False, ocr_svc=None):
    try:
        output_file = filename[:-4] + '_ocred.pdf'
        output_config = get_ocr_config(output_file, input_config=input_config)
        if ocr_svc is not None:
            output_config["ocr_svc"] = ocr_svc
        logging.info("Before calling finstinct-ocr-service {}".format(output_file))
        ocr_response = {}
        if use_cache:
            with open("azure_data.dict", "r") as cached_output:
                ocr_response["dict"] = [eval(cached_output.read())]
        else:
            ocr_response = ocr_pdf(filename, output_config)
        logging.info("After callling finstinct-ocr-service {}".format(output_file))
    except Exception as e:
        raise SystemError("Unexpected Exception occured during ocr of file {} ".format(filename))
    return ocr_response


def get_ocred_file(ocr_response):
    return ocr_response.get("pdf")


def check_is_scanned(filename):
    # Check if scanned or not using pdffonts
    out = check_output(['pdffonts', filename]).decode()
    return out.count('\n') <= 3 and "_ocred" not in filename


def get_ocr_config(output_file, input_config=None):
    # TODO Move this inline config to config file or passed from outside
    ocr_config = {
        "file_name": output_file,
        "min_font_size": 4, "dpi": 300, "img_fmt": "jpg",
        "draw_border": False, "output_word_by_word": True, "out_fmt": ["pdf", "dict"],
        "change_origin": "bottom-left", "dewarp": False, "DECISION_SLOPE": 2.0, "DECISION_NCLUSTERS": 3
    }
    if input_config is None or input_config.get("font") is None:
        ocr_config["font"] = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    # TODO move to environment variable or other password protected key file
    ocr_config["COMPUTER_VISION_SUBSCRIPTION_KEY"] = "0c44ce9535ec4082b129ed3f00b7178c"
    ocr_config["COMPUTER_VISION_ENDPOINT"] = "https://eastus.api.cognitive.microsoft.com/"
    return ocr_config


if __name__ == "__main__":
    pass
