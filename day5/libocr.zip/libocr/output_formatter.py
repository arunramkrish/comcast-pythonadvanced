from abc import ABC, abstractmethod


class OutputFormatter(ABC):
    @abstractmethod
    def output_ocr_result(self, ocr_result, output_config={}):
        pass
