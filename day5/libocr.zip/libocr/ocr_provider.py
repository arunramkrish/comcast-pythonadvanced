from abc import ABC, abstractmethod


class OcrProvider(ABC):
    @abstractmethod
    def ocr(self, file_name, output_config):
        pass
