import logging
import os
import sys
from subprocess import check_output
import time
from finstinct_config.loader import FinstinctConfig
config_obj = FinstinctConfig.get_config()


class AbbyyFreOcrProvider:
    """
    Virtually implements OcrProvider interface using Abbyy FRE's standalone SDK OCR Library.
    """
    def supports_multipage_pdf(self):
        return True

    def get_supported_output_formats(self):
        return ["pdf"]

    def get_processors_before_ocr(self):
        return []

    def ocr_to_pdf(self, file_path, output_config):
        return self.ocr(file_path, output_config)

    def ocr(self, file_path, output_config):
        try:
            logging.info("Uploading file {} using Abbyy FRE".format(file_path))
            result_file_path = output_config.get("file_name")
            check_output([config_obj.ocr_config.java_path, "-jar", config_obj.ocr_config.ocr_connector_path, file_path, result_file_path],
                         env={"JDK": config_obj.ocr_config.jdk_path,
                              "LD_LIBRARY_PATH": config_obj.ocr_config.ld_lib_path})
            # check_output(["/usr/finstinct/jdk1.8.0_91/bin/java", "-jar", "/usr/finstinct/connector-ocr-abbyy.jar", file_path, result_file_path],
            #              env={"JDK": "/usr/finstinct/jdk1.8.0_91",
            #                   "LD_LIBRARY_PATH": "/opt/ABBYY/FREngine12/Bin"})
            # check_output(["java", "-jar", "/opt/ABBYY/FREngine12/Samples/ocrutility.jar", file_path, result_file_path],
            #              env={"JDK":"appln/vmuser/finstinct/jdk1.8.0_91","LD_LIBRARY_PATH":"/opt/ABBYY/FREngine12/Bin"})
            logging.info("Successfully completed OCR using Abbyy FRE for {}".format(file_path))

        except Exception as e:
            logging.error("Unexpected Exception occured during ocr of file {} using abbyyfre sdk".format(file_path), exc_info = True)
            raise SystemError("Unexpected Exception occured during ocr of file {} using abbyyfre sdk".format(file_path))


if __name__ == "__main__":
    logging.basicConfig(format='%(asctime)s:%(levelname)s:%(message)s', stream=sys.stdout, level=logging.DEBUG)
    source_file = "F:/Learning/ComputerVision/Abbyy/SupportTickets/610_CO_12_832915_Pratheesh Certificate.pdf"
    target_file = "F:/Learning/ComputerVision/Abbyy/SupportTickets/610_CO_12_832915_Pratheesh Certificate_ocred.pdf"
    xml_file = "F:/Learning/ComputerVision/Abbyy/SupportTickets/610_CO_12_832915_Pratheesh Certificate_ocred.xml"

    # output_format = "xml"
    output_config = {
        "file_name": target_file,
        "xml_file_name": xml_file
    }
    language = "English"

    if os.path.isfile(source_file):
        AbbyyFreOcrProvider().ocr(source_file, output_config)
    else:
        logging.error("No such file: {}".format(source_file))
