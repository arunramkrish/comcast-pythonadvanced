#!/usr/bin/python3

# Usage: process.py <input file> <output file> [-l <Language>] [-pdf|-txt|-rtf|-docx|-xml]
import logging
import argparse
import os
import sys
import time
from libocr.abbyy_impl.abbyy_sdk import *

class AbbyyOcrProvider:
    """
    Virtually implements OcrProvider interface using Abbyy's OCR Library. Takes an image and returns a
    JSON containing texts along with their bounding boxes with coorinates and dimensions with reference to the image
    """

    def __init__(self):
        self.processor = None


    def supports_multipage_pdf(self):
        return True


    def get_supported_output_formats(self):
        return ["pdf"]


    def get_processors_before_ocr(self):
        return []


    def setup_processor(self):
        if "ABBYY_APPID" in os.environ:
            self.processor.ApplicationId = os.environ["ABBYY_APPID"]
        else:
            self.processor.ApplicationId = 'FinStinct'

        if "ABBYY_PWD" in os.environ:
            self.processor.Password = os.environ["ABBYY_PWD"]
        else:
            self.processor.Password = 'e8Ar00HPO5K2z223OJ7os4MU '

        # Proxy settings
        if "http_proxy" in os.environ:
            proxy_string = os.environ["http_proxy"]
            logging.info("Using http proxy at {}".format(proxy_string))
            self.processor.Proxies["http"] = proxy_string

        if "https_proxy" in os.environ:
            proxy_string = os.environ["https_proxy"]
            logging.info("Using https proxy at {}".format(proxy_string))
            self.processor.Proxies["https"] = proxy_string

    def create_processor_from_env(self, config):
            self.processor = AbbyyOnlineSdk()
            self.setup_processor()


    def ocr_to_pdf(self, file_path, output_config):
        return self.ocr(file_path, output_config)


    def ocr(self, file_path, output_config):
        if self.processor is None:
            self.create_processor_from_env(output_config)
        try:
            result_file_path = output_config.get("file_name")
            language = "English"
            output_format = "pdfSearchable"
            result_xml_file_path = None
            if output_config.get("xml_file_name") is not None:
                output_format += ",xml"
                result_xml_file_path = output_config.get("xml_file_name")

            logging.info("Uploading file {} using Abbyy".format(file_path))
            settings = ProcessingSettings()
            settings.Language = language
            settings.OutputFormat = output_format
            task = self.processor.process_image(file_path, settings)
            if task is None:
                logging.error("Error while doing OCR of file {} with ABBYY as process_image returned no task".format(file_path))
                raise SystemError("Error while doing OCR of file {} with ABBYY as process_image returned no task".format(file_path))

            if task.Status == "NotEnoughCredits":
                logging.error("Not enough credits to process the document {}. Please add more pages to your application's account.".format(file_path))
                return SystemError("Not enough credits to process the document {}. Please add more pages to your application's account.".format(file_path))

            logging.info("Doing OCR of {} using Abbyy, Obtatined task with Id = {} and task status {}".
                         format(file_path, task.Id, task.Status))

            # Wait for the task to be completed
            # Note: it's recommended that your application waits at least 2 seconds
            # before making the first getTaskStatus request and also between such requests
            # for the same task. Making requests more often will not improve your
            # application performance.
            # Note: if your application queues several files and waits for them
            # it's recommended that you use listFinishedTasks instead (which is described
            # at http://ocrsdk.com/documentation/apireference/listFinishedTasks/).

            while task.is_active():
                time.sleep(5)
                task = self.processor.get_task_status(task)

            logging.info("Status of OCR using Abbyy for file {} is {}".format(file_path, task.Status))

            if task.Status == "Completed":
                if task.DownloadUrl is not None:
                    self.processor.download_result(task, result_file_path, result_xml_file_path)
                    logging.info("Successfully OCRed using Abbyy. Result was written to {}".format(result_file_path))
            else:
                logging.error("OCR error using Abbyy for file {} Error processing task as task Status is not Completed but {}".format(file_path, task.Status))
                raise SystemError("OCR error using Abbyy for file {} Error processing task as task Status is not Completed but {}".format(file_path, task.Status))
        except Exception as e:
            logging.error("Unexpected Exception occured during ocr of file {} ".format(file_path), exc_info = True)
            raise SystemError("Unexpected Exception occured during ocr of file {} ".format(file_path))


if __name__ == "__main__":
    logging.basicConfig(format='%(asctime)s:%(levelname)s:%(message)s', stream=sys.stdout, level=logging.DEBUG)
    # source_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Platform-Cheque/Arun_1001_2.pdf"
    # target_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Platform-Cheque/Arun_1001_2_ocred.txt"
    # source_file = "C:/Users/Arunkumar/Downloads/1001.pdf"
    # target_file = "C:/Users/Arunkumar/Downloads/1001_ocred.rtf"
    # source_file = "C:/Users/Arunkumar/Downloads/3001.pdf"
    # target_file = "C:/Users/Arunkumar/Downloads/3001_ocred.rtf"
    # output_format = "rtf"

    # source_file = "C:/Users/Arunkumar/Downloads/Rupa - Statement.pdf"
    # target_file = "C:/Users/Arunkumar/Downloads/Rupa - Statement.rtf"
    # source_file = "F:/RamLabs/Consulting/Finstinct/src/finstinct-ocr-service/images/input/Eshwari-3.pdf"
    # target_file = "F:/RamLabs/Consulting/Finstinct/src/finstinct-ocr-service/images/input/Eshwari-3.xml"
    # output_format = "pdfSearchable"

    # source_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/BG-New/HDFC NEW KRO.pdf"
    # target_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/BG-New/HDFC NEW KRO_ocred.pdf"
    # xml_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/BG-New/HDFC NEW KRO_ocred.xml"

    # source_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/BG-Member-Letter/NseMemberLetter-2.pdf"
    # target_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/BG-Member-Letter/NseMemberLetter-2_ocred.pdf"
    # xml_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/BG-Member-Letter/NseMemberLetter-2_ocred.xml"

    # source_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/INDUSIND_MADHAV_ML.pdf"
    # target_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/INDUSIND_MADHAV_ML_ocred.pdf"
    # xml_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/INDUSIND_MADHAV_ML_ocred.xml"

    # source_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/TMB_EDEL_ML.pdf"
    # target_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/TMB_EDEL_ML_ocred.pdf"
    # xml_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/TMB_EDEL_ML_ocred.xml"

    # source_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/YES_EDEL_ML.pdf"
    # target_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/YES_EDEL_ML_ocred.pdf"
    # xml_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/YES_EDEL_ML_ocred.xml"

    source_file = "F:/Learning/ComputerVision/Abbyy/SupportTickets/610_CO_12_832915_Pratheesh Certificate.pdf"
    target_file = "F:/Learning/ComputerVision/Abbyy/SupportTickets/610_CO_12_832915_Pratheesh Certificate_ocred.pdf"
    xml_file = "F:/Learning/ComputerVision/Abbyy/SupportTickets/610_CO_12_832915_Pratheesh Certificate_ocred.xml"

    # output_format = "xml"
    output_config = {
        "file_name": target_file,
        "xml_file_name": xml_file
    }
    language = "English"

    if os.path.isfile(source_file):
        AbbyyOcrProvider().ocr(source_file, output_config)
    else:
        print("No such file: {}".format(source_file))
