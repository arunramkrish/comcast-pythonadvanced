import math
import re
import os
import PyPDF2
from pdfminer.converter import PDFPageAggregator
from pdfminer.layout import LAParams, LTFigure
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.pdfpage import PDFPage
from libocr.adapter import ocr_adapter
from libocr import ocr_pdf_to_text_pdf
from functools import lru_cache
import logging
logging.basicConfig(level=logging.DEBUG, format='[%(asctime)s] %(levelname)s: %(message)s')
logger = logging.getLogger(__name__)


def extract_layout(page_obj):
    rsrcmgr = PDFResourceManager()
    rsrcmgr_objectwise = PDFResourceManager()
    # retstr = StringIO()
    # codec = 'utf-8'
    laparams = LAParams()
    # device = TextConverter(rsrcmgr, retstr, codec=codec, laparams=laparams)
    device_objectwise = PDFPageAggregator(rsrcmgr, laparams=laparams)

    # interpreter = PDFPageInterpreter(rsrcmgr, device)
    interpreter_objectwise = PDFPageInterpreter(rsrcmgr_objectwise, device_objectwise)

    interpreter_objectwise.process_page(page_obj)
    layout = device_objectwise.get_result()

    return layout


def get_pages(filename):
    if isinstance(filename, str):
        return PDFPage.get_pages(open(filename, "rb"))
    else:
        return PDFPage.get_pages(filename)


def get_ocr_score(xml_filename):
    """
    Fetches the file level scan quality score
    """
    pat = re.compile(f"charParams.*? charConfidence=\"([0-9-]+)\"")
    scores = []
    if not os.path.exists(xml_filename):
        return 100.0
    with open(xml_filename, "r") as xml:
        for line in xml:
            match = pat.search(line)
            if match:
                scores.append(int(match.groups(0)[0]))

    ocr_score = sum(scores) / len(scores)

    # Remap ocr score distribution to make the values go closer to 1 as abbyy typically only goes till 0.6
    # The remapping happens using a boost in score that is calculated as per the original score and how that
    # maps onto an inverted normal distribution curve from -1 to 1
    # Finally the score is clamped at 0 and 1
    ocr_score = ocr_score / 100
    remap_center = 0.2
    rescaled = (ocr_score * 2) - 1  # Scaled into the range [-1, 1]
    weight = (math.e ** (rescaled * rescaled * remap_center)) / (math.sqrt(2 * math.pi))
    ocr_score = ocr_score * (1 + weight)
    ocr_score = 0 if ocr_score < 0 else ocr_score
    ocr_score = 1 if ocr_score > 1 else ocr_score
    ocr_score *= 100

    return ocr_score


def get_pdf_ocr_score(filename):
    alt_pdf = PyPDF2.PdfFileReader(open(filename, 'rb'), strict=False)
    total_pages = alt_pdf.getNumPages()

    logger.info(f"About to check file  {filename} if it is scanned")
    try:
        is_scanned = ocr_adapter.check_is_scanned(filename)
        if not is_scanned:
            logger.info(f"The filename {filename} is not scanned. So need of OCR.")
            return 0
    except Exception as e:
        logger.error(f"Error while checking if given file {filename} is scanned", exc_info=True)
        return 0

    page_threshold = 3
    try:
        if total_pages > page_threshold:
            # Process First, Middle and Last if pdf pages length more than 3
            logger.info(f'Pdf Pages more than 3 and is scanned {filename}. Creating a subset')
            page_nos = [0, int(total_pages/2), total_pages-1]
            scanned_page_nums = []
            # scanned_pages = PyPDF2.PdfFileWriter()
            logger.info(f'Merging pages of front, middle and last of {filename} to new pdf.')
            scanned_pages = PyPDF2.PdfFileMerger(strict=False)
            for page_num in page_nos:
                scanned_page_nums.append(page_num)
                scanned_pages.append(alt_pdf, pages=(page_num, page_num + 1))
            temp_name = filename[:-4]+'_interim.pdf'

            with open(temp_name, 'wb') as temp_file:
                scanned_pages.write(temp_file)
                temp_file.flush()
            filename = temp_name
            logger.info(f'Successfully merged front, middle, last pages with filename: {filename}')
    except Exception as e:
        logger.error(f'Error while generating an interim PDF for OCR score: {filename}')

    ocr_score = 0
    # find ocr score if scanned pages
    logger.info(f'About to compute OCR score for {filename}')
    try:
        ocr_response = do_ocr(filename, use_cache=False)
        logger.info(f'Successfully completed OCR for file {filename}')
        if ocr_adapter.get_ocred_file(ocr_response) is not None:
            xml_filename = ocr_response.get('xml')
            ocr_score = get_ocr_score(xml_filename)
        logger.info(f"Successfully calculated OCR score for {filename} with ocr_score as {ocr_score}")
        return ocr_score
    except Exception as e:
        logger.error(f"Error while performing OCR and computing score for file {filename}", exc_info=True)


@lru_cache(maxsize=2)
def do_ocr(filename, use_cache=False):
    output_file = filename[:-4] + '_ocred.pdf'
    output_config = generate_ocr_config(output_file)
    logging.info("Before calling finstinct-ocr-service {}".format(output_file))
    ocr_response = {}
    if use_cache:
        with open("azure_data.dict", "r") as cached_output:
            ocr_response["dict"] = [eval(cached_output.read())]
    else:
        ocr_response = ocr_pdf_to_text_pdf.ocr_pdf(filename, output_config)
    logging.info("After callling finstinct-ocr-service {}".format(output_file))
    return ocr_response


def generate_ocr_config(output_file):
    # TODO Move this inline config to config file or passed from outside
    xml_output_file = output_file[:-4] + '.xml'
    ocr_config = {
        "file_name": output_file,
        "xml_file_name": xml_output_file,
        "font": "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "min_font_size": 4, "dpi": 200, "img_fmt": "jpg",
        "draw_border": False, "output_word_by_word": True, "out_fmt": ["pdf"],
        "change_origin": "bottom-left", "dewarp": False, "DECISION_SLOPE": 2.0, "DECISION_NCLUSTERS": 3
    }
    # if ocr_provider_key == "azure":
    ocr_config["COMPUTER_VISION_SUBSCRIPTION_KEY"] = "0c44ce9535ec4082b129ed3f00b7178c"
    ocr_config["COMPUTER_VISION_ENDPOINT"] = "https://eastus.api.cognitive.microsoft.com/"
    return ocr_config


if __name__ == "__main__":
    file = "../BG renewal document_ICICI KRO 5.pdf"
    score = get_pdf_ocr_score(file)
    print(score)
