#!/usr/bin/python3

# Usage: process.py <input file> <output file> [-l <Language>] [-pdf|-txt|-rtf|-docx|-xml]
import logging
import argparse
import os
import sys
import time
from libocr.abbyyfreweb_impl.abbyyfreweb_sdk import *


class AbbyyFreWebOcrProvider:
    """
    Virtually implements OcrProvider interface using Abbyy's FRE OCR Web API connector created in FinStinct.
    """

    def __init__(self):
        self.processor = None

    def supports_multipage_pdf(self):
        return True

    def get_supported_output_formats(self):
        return ["pdf"]

    def get_processors_before_ocr(self):
        return []

    def create_processor_from_env(self, config):
        self.processor = AbbyyFreWebSdk()

    def ocr_to_pdf(self, file_path, output_config):
        return self.ocr(file_path, output_config)

    def ocr(self, file_path, output_config):
        if self.processor is None:
            self.create_processor_from_env(output_config)
        try:
            result_file_path = output_config.get("file_name")
            language = "English"
            output_format = "pdfSearchable"
            result_xml_file_path = None
            if output_config.get("xml_file_name") is not None:
                output_format += ",xml"
                result_xml_file_path = output_config.get("xml_file_name")

            logging.info("Uploading file {} using AbbyyFRE Web API".format(file_path))
            settings = ProcessingSettings()
            settings.Language = language
            settings.OutputFormat = output_format
            task_id = self.processor.process_image(file_path, settings)
            if task_id is None:
                logging.error("Error while doing OCR of file {} with ABBYY FRE Web as process_image returned no task".format(file_path))
                raise SystemError("Error while doing OCR of file {} with ABBYY Web FRE as process_image returned no task".format(file_path))

            # fetch result using task_id
            logging.info("Doing OCR of {} using Abbyy FRE Web, Obtatined task with Id = {}. Fetching result now".
                         format(file_path, task_id))

            self.processor.download_result(task_id, result_file_path, result_xml_file_path)
            logging.info("Successfully OCRed using Abbyy FRE Web. Result was written to {}".format(result_file_path))
        except Exception as e:
            logging.error("Unexpected Exception occured during ocr of file {} ".format(file_path), exc_info = True)
            raise SystemError("Unexpected Exception occured during ocr of file {} ".format(file_path))


if __name__ == "__main__":
    logging.basicConfig(format='%(asctime)s:%(levelname)s:%(message)s', stream=sys.stdout, level=logging.DEBUG)
    # source_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Platform-Cheque/Arun_1001_2.pdf"
    # target_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Platform-Cheque/Arun_1001_2_ocred.txt"
    # source_file = "C:/Users/Arunkumar/Downloads/1001.pdf"
    # target_file = "C:/Users/Arunkumar/Downloads/1001_ocred.rtf"
    # source_file = "C:/Users/Arunkumar/Downloads/3001.pdf"
    # target_file = "C:/Users/Arunkumar/Downloads/3001_ocred.rtf"
    # output_format = "rtf"

    # source_file = "C:/Users/Arunkumar/Downloads/Rupa - Statement.pdf"
    # target_file = "C:/Users/Arunkumar/Downloads/Rupa - Statement.rtf"
    # source_file = "F:/RamLabs/Consulting/Finstinct/src/finstinct-ocr-service/images/input/Eshwari-3.pdf"
    # target_file = "F:/RamLabs/Consulting/Finstinct/src/finstinct-ocr-service/images/input/Eshwari-3.xml"
    # output_format = "pdfSearchable"

    # source_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/BG-New/HDFC NEW KRO.pdf"
    # target_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/BG-New/HDFC NEW KRO_ocred.pdf"
    # xml_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/BG-New/HDFC NEW KRO_ocred.xml"

    # source_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/BG-Member-Letter/NseMemberLetter-2.pdf"
    # target_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/BG-Member-Letter/NseMemberLetter-2_ocred.pdf"
    # xml_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/BG-Member-Letter/NseMemberLetter-2_ocred.xml"

    # source_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/INDUSIND_MADHAV_ML.pdf"
    # target_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/INDUSIND_MADHAV_ML_ocred.pdf"
    # xml_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/INDUSIND_MADHAV_ML_ocred.xml"

    # source_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/TMB_EDEL_ML.pdf"
    # target_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/TMB_EDEL_ML_ocred.pdf"
    # xml_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/TMB_EDEL_ML_ocred.xml"

    # source_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/YES_EDEL_ML.pdf"
    # target_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/YES_EDEL_ML_ocred.pdf"
    # xml_file = "F:/RamLabs/Consulting/Finstinct/Documents/SampleFiles/Parivartan/FD-Member-Letter/YES_EDEL_ML_ocred.xml"

    source_file = "F:/Learning/ComputerVision/Abbyy/SupportTickets/610_CO_12_832915_Pratheesh Certificate.pdf"
    target_file = "F:/Learning/ComputerVision/Abbyy/SupportTickets/610_CO_12_832915_Pratheesh Certificate_ocred.pdf"
    xml_file = "F:/Learning/ComputerVision/Abbyy/SupportTickets/610_CO_12_832915_Pratheesh Certificate_ocred.xml"

    # output_format = "xml"
    output_config = {
        "file_name": target_file,
        "xml_file_name": xml_file
    }
    language = "English"

    if os.path.isfile(source_file):
        AbbyyFreWebOcrProvider().ocr(source_file, output_config)
    else:
        print("No such file: {}".format(source_file))
