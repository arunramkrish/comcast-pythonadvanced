#!/usr/bin/python

# Usage: process.py <input file> <output file> [-l <Language>] [-pdf|-txt|-rtf|-docx|-xml]

import shutil
import requests


class ProcessingSettings:
	Language = "English"
	OutputFormat = "pdfSearchable"


class Task:
	Status = "Unknown"
	Id = None
	DownloadUrl = None

	def is_active(self):
		if self.Status == "InProgress" or self.Status == "Queued":
			return True
		else:
			return False


class AbbyyFreWebSdk:
	# TODO Move to config
	ServerUrl = "https://172.17.106.232/connector-ocr-abbyy-web/api/ocr/"

	def process_image(self, file_path, settings):
		request_url = self.get_request_url("processfile")

		with open(file_path, 'rb') as image_file:
			image_data = image_file.read()

		headers = {"Content-Type": "multipart/form-data"}
		response = requests.post(request_url, files={"file": image_data}, verify=False)

		# Any response other than HTTP 200 means error - in this case exception will be thrown
		response.raise_for_status()

		# parse response xml and extract task ID
		task_id = response.text
		return task_id

	def download_result(self, task_id, output_path, xml_output_path = None):
		# TODO Move this hardcoded URL to configuration
		result_url = "https://172.17.106.232/connector-ocr-abbyy-web/api/ocr/result/" + task_id

		pdf_url = result_url + "/pdf"
		file_response = requests.get(pdf_url, stream=True, verify=False)
		with open(output_path, 'wb') as output_file:
			shutil.copyfileobj(file_response.raw, output_file)

		if xml_output_path is not None:
			xml_url = result_url + "/xml"
			xml_response = requests.get(xml_url, stream=True, verify=False)
			with open(xml_output_path, 'wb') as xml_output_file:
				shutil.copyfileobj(xml_response.raw, xml_output_file)

	def get_request_url(self, url):
		return self.ServerUrl.strip('/') + '/' + url.strip('/')
