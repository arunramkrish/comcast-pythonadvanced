from libpdf.pdf_util import PdfFile
from libocr import ocr_img_to_text_pdf
import logging
import sys
import os
from libocr.factory import ocr_provider_factory

# from time import sleep, time


def get_page_size(pdf_info):
    page_size = pdf_info["Page size"]
    delim_index = page_size.index(" x ")
    width = float(page_size[:delim_index])
    height = page_size[delim_index + 3:]
    units_index = height.index(" ")
    units = height[units_index + 1:]
    height = float(height[:units_index])
    return (width, height, units)


def get_ocr_provider_from_file_name(file_name, available_providers, sep=os.sep):
    head, tail = os.path.split(file_name)
    try:
        first_key_word_end_index = tail.index("_")
    except ValueError as e:
        return None
    if first_key_word_end_index != -1:
        first_key_word = tail[0:first_key_word_end_index]
        try:
            # in case first_key_word has dots (like job id prefix), take it after the dot
            dot_index = first_key_word.index(".")
            first_key_word = first_key_word[dot_index + 1: len(first_key_word)]
        except ValueError as e:
            pass

        try:
            logging.info("File prefix to check OCR provider {}".format(first_key_word))
            key_index = available_providers.index(first_key_word)
            logging.info("File prefix determines OCR provider{} at index {}".format(first_key_word, key_index))
            return first_key_word
        except ValueError as e:
            return None


def get_ocr_service(pdf_file, config):
    svc_name = config.get("ocr_svc")
    logging.info("Got the following service name {} from input file {}".format(svc_name, pdf_file))
    if svc_name is None:
        svc_name = get_ocr_provider_from_file_name(pdf_file, ocr_provider_factory.avaiable_providers())

        if svc_name is None:
            svc_name = ocr_provider_factory.get_default_provider()
            logging.info("Got default service name as OCR provider {}".format(svc_name))
    return svc_name


def ocr_pdf(pdf_file, config={}):
    try:
        logging.info("Received OCR request for file {} with config {}".format(pdf_file, config))

        svc_name = get_ocr_service(pdf_file, config)
        ocr_service = ocr_provider_factory.get_ocr_provider(svc_name)

        if ocr_service.supports_multipage_pdf() is True:
            ocr_service.ocr_to_pdf(pdf_file, config)
            ocr_response = {
                "pdf": config.get("file_name"),
                "xml": config.get("xml_file_name")
            }
            return ocr_response

        # Do OCR page by page
        # get pdf info to calculate size
        pdf_info = PdfFile.pdfinfo_from_path(pdf_file)
        (width, height, units) = get_page_size(pdf_info)
        config["width"] = width
        config["height"] = height
        config["units"] = units

        # Part #1 : Converting PDF to images

        # Store all the pages of the PDF in a variable
        dpi = config.get("dpi") if config.get("dpi") else 300
        fmt = config.get("img_fmt") if config.get("img_fmt") else "jpg"
        logging.info("Converting PDF file {} to images with dpi {} and format {}".format(pdf_file, str(dpi), fmt))
        pages = PdfFile.convert_from_path(pdf_file, dpi=dpi, fmt=fmt)
        logging.info("Successfully converted PDF file {} to {} images ".format(pdf_file, str(len(pages))))

        # list of images
        image_files = []
        # Iterate through all the pages stored above
        image_counter = 1
        for page in pages:
            # config["image_scale"] = page.height / config["height"]
            config["image_scale"] = dpi

            # Declaring filename for each page of PDF as JPG
            # For each page, filename will be:
            # PDF page n -> page_n.jpg

            filename = pdf_file + "_page_" + str(image_counter) + ".jpg"

            # Save the image of the page in system
            page.save(filename, 'JPEG')

            image_files.append(filename)
            image_counter = image_counter + 1

        # Part #2 - Recognizing text from the images using OCR
        # Creating a text file to write the output
        if config["file_name"] is None:
            config["file_name"] = pdf_file + "_ocred.pdf"
        logging.info("Before sending images of file {} for OCR ".format(pdf_file))
        ocr_img_to_text_pdf.ocr_images(image_files, config)
        logging.info("Successfully converted images of file {} from OCR ".format(pdf_file))

        # TODO later populate OCR response based on what the user has asked
        ocr_response = {
            "dict": config.get("pages")
        }
    except Exception as e:
        raise SystemError("Unexpected Exception occured during ocr of file {} ".format(pdf_file))
    return ocr_response


if __name__ == "__main__":
    file_name = "tess_file_for_tesseract.pdf"
    print("file {} maps to {}".format(file_name,
                                     get_ocr_provider_from_file_name(file_name,
                                                                     ocr_provider_factory.avaiable_providers())))
    file_name = "f:/test/something/with_prefix/x84kgl.abbyyfre_file_for_tesseract.pdf"
    print("file {} maps to {}".format(file_name,
                                     get_ocr_provider_from_file_name(file_name,
                                                                     ocr_provider_factory.avaiable_providers())))
    file_name = "jobid8374.abbyy_file_for_tesseract.pdf"
    print("file {} maps to {}".format(file_name,
                                     get_ocr_provider_from_file_name(file_name,
                                                                     ocr_provider_factory.avaiable_providers())))

if __name__ == "__test_main__":
    logging.basicConfig(format='%(asctime)s:%(levelname)s:%(message)s', stream=sys.stdout, level=logging.DEBUG)
    preprocessors = ["deskew", "rotate", "dewarp"]
    # "out_fmt": ["pdf", "dom", "dict"]
    # ex_azure_config = {"min_font_size": 4, "dpi": 100, "img_fmt": "jpg", "draw_border": False,
    #                    "output_word_by_word": True, "out_fmt": ["pdf","dict"],
    #                    "COMPUTER_VISION_SUBSCRIPTION_KEY": "d4ea6527a8094adaa13ce56c53fd2005",
    #                    "COMPUTER_VISION_ENDPOINT":"https://finstinct-ocr.cognitiveservices.azure.com/",
    #                    "change_origin": "bottom-left"}
    ex_corp_azure_config = {"min_font_size": 4, "dpi": 300, "img_fmt": "jpg", "draw_border": True,
                            "output_word_by_word": True, "out_fmt": ["dom"], "rotation": True,
                            "ocr_angle_rotate_threshold": 15.0, "DECISION_SLOPE": 2.0, "DECISION_NCLUSTERS": 3,
                            "change_origin": "bottom-left"}
    # "process_pages": [0, 1, 9],
    # "change_origin": "bottom-left"}
    # ext_corp_azure_config = {"file_name": PDF_file + "_ocred.pdf", "min_font_size": 14, "dpi": 100, "img_fmt": "jpg",
    #                     "draw_border": False, "output_word_by_word": True, "ocr_svc": "azure", "out_fmt": "pdf",
    #                     "COMPUTER_VISION_SUBSCRIPTION_KEY": "0c44ce9535ec4082b129ed3f00b7178c",
    #                     "COMPUTER_VISION_ENDPOINT":"https://eastus.api.cognitive.microsoft.com/"}

    # ex_tesseract_config = {"min_font_size": 14, "dpi": 100, "img_fmt": "jpg",
    #                        "draw_border": True, "output_word_by_word": True, "ocr_svc": "tess", "out_fmt": "pdf",
    #                        "change_origin": "bottom-left",
    #                        "process_pages": [0, 1, 9], "ocr_angle_rotate_threshold": 15.0,
    #                        "DECISION_SLOPE": 2.0, "DECISION_NCLUSTERS": 3
    #                        }
    # "preprocess1": "blur", "preprocess2": "thresh"}

    base_input_dir = "F:/RamLabs/Consulting/Finstinct/Documents/Testing/SampleFiles/ExperienceLetters/"
    stmt_base_input_dir = "F:/RamLabs/Consulting/Finstinct/Documents/Testing/SampleFiles/StatementHub/"

    ocr_error_files = [
    ]
    input_files = [
        "2C. Experience Certificate - pace commodity.pdf", "ABK_ExperienceCertificate-signed.pdf",
        "ApplicationQuery-signed_SPA.pdf", "CACertifiedExperienceCertificate-signed.pdf",
        "CapitalMarketexperience-signed.pdf", "expcertTS-signed.pdf", "ExperianceCert-signed.pdf",
        "Experience Certificate.pdf", "Experience-signed.pdf", "ExperienceCertificate-signed-Reliance.pdf",
        "Experienceletter-signed_Abans.pdf", "ExperienceProofofDesignatedDirector.pdf",
        "Experience_INDUSIND LETTER.pdf", "Experience_ISec_2014.pdf", "Experience_JM.pdf",
        "Experience_KOTAK LETTER_2011.pdf", "Experience_Kotak_2019.pdf", "Experience_MILESTONE LETTER.pdf",
        "Experience_PRUDENT LETTER.pdf", "ICICI SECURITIES RELIEVING LETTER (1).pdf", "rajeshexp-signed.pdf",
        "RajivAashishExpCertificate-signed.pdf"
    ]
    stmt_input_files = [
        "Andhra Bank.pdf",
        "Axis_Normal.pdf",
        "Bandhan-Bank.pdf",
        "Bank Statement_Allahabad Bank_1562922578071.pdf",
        "Bank Statement_Bank Of India_1562560227985.pdf",
        "bank_3.pdf",
        "bank_7.pdf",
        "bank_8.pdf",
        "bank_118.pdf",
        "BOI-Kannan.pdf",
        "Chequebook-bank-statement.pdf",
        "Divine.pdf",
        "Eshu.pdf",
        "Eshwari-2.pdf",
        "Eshwari-3.pdf",
        "Eshwari-4.pdf",
        "Eshwari-5.pdf",
        "Fashionista-Canara-Bank.pdf",
        "JalGaon-Bank.pdf",
        "Kotak-Bank-Statement.pdf",
        "Krishna-Fashion.pdf",
        "Microsec-Capital.pdf",
        "neeraj gupta_Bank Statement_1.pdf",
        "neeraj gupta_Bank Statement_2.pdf",
        "neeraj gupta_ledger Statement.pdf",
        "Rajwadi-SBI.pdf",
        "RSK - statement.pdf",
        "Rupa - Statement.pdf",
        "Shree-Ram-SBI.pdf",
        "Vardan-Dresses-SBI.pdf",
        "Zaheer-Saraswat-Coop-Bank.pdf"
    ]
    base_output_dir = "F:/RamLabs/Consulting/Finstinct/Documents/Testing/SampleFiles/ExperienceLetters/ocred/"
    stmt_base_output_dir = "F:/RamLabs/Consulting/Finstinct/Documents/Testing/SampleFiles/StatementHub/dom/"
    output_suffix = "_ocred.pdf"

    # start_index = 3
    # end_index = len(input_files)
    start_index = 0
    # end_index = len(input_files)
    end_index = 1
    for i in range(start_index, end_index):
        config_copy = dict(ex_corp_azure_config)
        filename = base_input_dir + input_files[i]
        config_copy["file_name"] = base_output_dir + input_files[i] + output_suffix
        ocr_pdf(filename, config_copy)
        pages = ex_corp_azure_config.get("pages")
