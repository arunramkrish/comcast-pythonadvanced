from libocr.util import font_util
from libocr.output_formatter import OutputFormatter
from libpdf.pdf_util import PDF

INCHES_TO_POINT = 72


class PdfOutputFormatter:

    def __get_coord(self, bounding_box) -> dict:
        coord = {}
        coord["x"] = bounding_box[0];
        coord["y"] = bounding_box[1];
        coord["width"] = bounding_box[2] - bounding_box[0];
        coord["height"] = bounding_box[7] - bounding_box[1];

        return coord

    def __transform_coord(self, input_coord, source_size, target_size) -> dict:
        input_coord["x"] = input_coord["x"] * INCHES_TO_POINT / target_size["image_scale"]
        input_coord["y"] = input_coord["y"] * INCHES_TO_POINT / target_size["image_scale"]
        input_coord["width"] = input_coord["width"] * INCHES_TO_POINT / target_size["image_scale"]
        input_coord["height"] = input_coord["height"] * INCHES_TO_POINT / target_size["image_scale"]

    def __set_font_size_to_fit(self, pdf, w, h, txt, font_name):
        current_width = pdf.get_string_width(txt)
        width, current_height = font_util.get_text_size(txt, pdf.font_size, font_name)

        current_font = pdf.font_size
        # while ((current_width > w) or (current_height > h)) and (current_font > 0):
        while (current_width < w) and (current_height < h):
            current_font = current_font + 0.5
            pdf.set_font_size(current_font)
            current_width = pdf.get_string_width(txt)
            width, current_height = font_util.get_text_size(txt, pdf.font_size, font_name)

        # if current_font > 1:
            # to be on safer size, intentionally reduce 1 more font
        pdf.set_font_size(current_font - 0.5)
        # else:
        #     print("Live with it")

    def __write_contents(self, content_obj, pdf, result_page_size, output_config):
        """
        Write the text contents as present in "text" attribute of given content_obj.
        Text is written inside the location of the bounding box.
        """
        if content_obj["text"] == "Scanned with CamScanner":
            return

        coord = self.__get_coord(content_obj["bounding_box"])

        # transform to page size
        self.__transform_coord(coord, result_page_size, output_config)
        pdf.set_xy(coord["x"], coord["y"])

        if output_config["draw_border"]:
            pdf.rect(coord["x"], coord["y"], w=coord["width"], h=coord["height"])

        pdf.set_xy(coord["x"], coord["y"])

        pdf.set_font_size(output_config["min_font_size"])
        font_name = output_config.get("font")
        if font_name is not None and font_name != "":
            self.__set_font_size_to_fit(pdf, w=coord["width"], h=coord["height"], txt=content_obj["text"],
                                        font_name=font_name)
        else:
            self.__set_font_size_to_fit(pdf, w=coord["width"], h=coord["height"], txt=content_obj["text"])

        # pdf.cell(w=coord["width"], h=coord["height"], txt=line["text"])
        pdf.cell(w=coord["width"], h=coord["height"], txt=content_obj["text"])

    def output_ocr_result(self, ocr_result, output_config={}):
        if ocr_result is None:
            if (output_config["total_pages"] - 1) == output_config["current_page"]:
                pdf = output_config.get("pdf")
                if pdf is not None:
                    pdf.output(output_config["file_name"], "F")
            return

        result_page_size = {"width": ocr_result[0]["width"], "height": ocr_result[0]["height"]}
        custom = "(" + str(output_config["width"]) + "," + str(output_config["height"]) + ")"

        pdf_size = []
        pdf_size.append(result_page_size["width"] * INCHES_TO_POINT / output_config["image_scale"])
        pdf_size.append(result_page_size["height"] * INCHES_TO_POINT / output_config["image_scale"])
        if (output_config["current_page"] == 0) or output_config.get("pdf") is None:
            pdf = PDF(unit="pt", format=pdf_size)
            pdf.set_auto_page_break(False, 0)
            pdf.set_margins(0, 0, 0)
            output_config["pdf"] = pdf
        else:
            pdf = output_config["pdf"]

        for page in ocr_result:
            pdf.add_page()
            for block in page["blocks"]:
                for line in block["lines"]:
                    if output_config["output_word_by_word"]:
                        for word in line["words"]:
                            self.__write_contents(word, pdf, result_page_size, output_config)
                    else:
                        self.__write_contents(line, pdf, result_page_size, output_config)

        if (output_config["total_pages"] - 1) == output_config["current_page"]:
            pdf.output(output_config["file_name"], "F")


OutputFormatter.register(PdfOutputFormatter)
