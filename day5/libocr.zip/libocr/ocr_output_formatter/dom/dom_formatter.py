from libocr.output_formatter import OutputFormatter
import json
import logging
import statistics
import re
import numpy as np
from libocr.util.stat_util import StatUtil


class DomOutputFormatter:

    def output_ocr_result(self, ocr_result, output_config={}):
        if output_config.get("pages") is None:
            output_config["pages"] = []
        if ocr_result is not None:
            for page in ocr_result:
                output_config["pages"].append(page)

        if output_config["current_page"] == output_config["total_pages"] - 1:
            # we have reached the last page
            if output_config.get("file_name") is not None:
                with open(output_config.get("file_name"), 'w') as file:
                    for page in output_config["pages"]:
                        page_doc = PageDocument(page)
                        file.write(str(page_doc))
            else:
                for page in output_config["pages"]:
                    page_doc = PageDocument(page)
                    print(page_doc)


class PageDocument:
    """
    PDFMiner page structure =>LTPage(bbox,height,x0,x1,y0,y1,groups,rotate,pageid,width) -> [LTTextBoxHorizontal( ->
    [LTTextLineHorizontal -> [LTChar(fontname,matrix,size,upright,_text)]]]
    """

    def __init__(self, page):
        self.page_index = page.get("page")
        self.width = page.get("width")
        self.height = page.get("height")

        # list to hold all noisy blocks like height which is less than minimum height of block
        self.noisy_blocks = []

        # Put individual blocks into one list
        self.__load_all_blocks(page.get("blocks"))

        # Derive the metrics from individual blocks - min height, min width (to determine possibly 1 (non-special)
        # character width), max height, min height, avg height, possibly frequency distribution
        self.__compute_block_metrics()

        # As it is observed that there is no prescribed order of the blocks, arrange it from top to bottom,
        # left to right
        self.__clean_and_sort_blocks()

        # TODO some blocks with only one special character has very minimum height and width, may be try to enlarge
        #  that to minimum size and ignore them from above metrics

        # Group individual word blocks as lines if their bounding boxes are overlapping. Do not worry if they are
        # imperfect as we eventually might get better mapping as we reiterate when we identify sections and realign
        # the lines within section
        self.__organize_lines_top_down()

        # compute metrics based on lines - min height, max height, avg height
        self.__compute_line_metrics()

        # parse lines and based on the layout of the line and the current state of the parser decide which path to take

        # organize sections by grouping lines based on gaps between them (0.5 line spacing, single line / double line spacing between them)
        #  first identify vertically stacked sections => we should get the page header, title, content as separate sections
        self.__organize_vertical_sections()

        # TODO for each section in the vertically stacked section, see if there is horizontally stacked section by
        #  checking the space between word block that runs throught the complete height of the section => we should
        #  at the least separate left and right aligned sections on top

        # for each section, check if there exists a matrix arrangement and create tables
        self.__identify_tables_in_sections()

        # TODO Merge subsequent tables that has either column alignment difference or additional columns are
        #  identified based on the arrangements of words within a cell

        # TODO Identify header and identify (predict) the data type of column

        # TODO if there is no matrix arrangement, create paragraph model with lines readable from left to right

    def __load_all_blocks(self, ocr_blocks):
        """Put individual blocks into one list"""
        self.all_blocks = []
        for block_index, ocr_block in enumerate(ocr_blocks):
            for line_index, ocr_line in enumerate(ocr_block.get("lines")):
                for word_index, ocr_word in enumerate(ocr_line.get("words")):
                    word = Word(ocr_word, ocr_line, line_index, ocr_block, block_index)
                    print(word)
                    self.all_blocks.append(word)

    @classmethod
    def is_only_special_chars(cls, text):
        regex = re.compile('[,`~_."\'-]*')
        match = regex.search(text)
        if match is None:
            return False
        return (len(match.group(0)) == len(text.strip()))

    def __compute_block_metrics(self):
        # compute metrics based on blocks - min height, max height, avg height
        is_valid_block = lambda x: not PageDocument.is_only_special_chars(x.text)
        valid_blocks = list(filter(is_valid_block, self.all_blocks))
        # valid_blocks = self.all_blocks
        blocks_height = [x.bounding_box.height for x in valid_blocks]
        self.min_block_height = min(blocks_height)
        self.max_block_height = max(blocks_height)
        self.avg_block_height = statistics.mean(blocks_height)
        self.blocks_with_min_height = list(
            filter(lambda x: x.bounding_box.height == self.min_block_height, valid_blocks))
        self.blocks_with_max_height = list(
            filter(lambda x: x.bounding_box.height == self.max_block_height, valid_blocks))
        logging.debug("Height: min = {}, max = {}, avg = {}".format(self.min_block_height, self.max_block_height,
                                                                    self.avg_block_height))
        logging.debug("Block with min height " + "|".join(map(str, self.blocks_with_min_height)))
        logging.debug("Block with max height " + "|".join(map(str, self.blocks_with_max_height)))

        logging.debug("Frequency Distribution of Height")
        logging.debug(StatUtil.frequency_distribution(blocks_height))

        logging.debug("Outliers based on IQR")
        logging.debug(StatUtil.get_outliers_using_iqr(blocks_height))

        logging.debug("Outliers based on Z-Score")
        logging.debug(StatUtil.get_outliers_using_zscore(blocks_height))

    def __compute_line_metrics(self):
        # compute metrics based on lines - min height, max height, avg height
        self.line_gaps = []
        self.line_min_left = []
        self.line_max_right = []
        self.gaps_btw_words = []

        for i in range(len(self.lines) - 1):
            # as the bounding box of a line is the surrounding bounding boxes of all words inside the line,
            # this might overlap with the bounding boxes of adjacent lines if there is skew. We can safely calculate
            # the vertical distance between the first word of both the lines
            self.line_gaps.append(
                self.lines[i].words[0].bounding_box.bottom - self.lines[i + 1].words[0].bounding_box.top)
            self.line_min_left.append(min(word.bounding_box.left for word in self.lines[i].words))
            self.line_max_right.append(max(word.bounding_box.right for word in self.lines[i].words))

            for word_index, word in enumerate(self.lines[i].words):
                if word_index < (len(self.lines[i].words) - 1):
                    self.gaps_btw_words.append(self.lines[i].words[word_index + 1].bounding_box.left - word.bounding_box.right)

        self.min_line_gaps = min(self.line_gaps)
        self.max_line_gaps = max(self.line_gaps)
        self.avg_line_gaps = statistics.mean(self.line_gaps)

        # TODO possibly remove these member variables after freezing the code
        self.lines_with_min_gap = []
        self.lines_with_max_gap = []
        for i in range(len(self.line_gaps)):
            if (self.line_gaps[i] == self.min_line_gaps):
                self.lines_with_min_gap.append(self.lines[i])
                self.lines_with_min_gap.append(self.lines[i + 1])
            if (self.line_gaps[i] == self.max_line_gaps):
                self.lines_with_max_gap.append(self.lines[i])
                self.lines_with_max_gap.append(self.lines[i + 1])

        logging.debug("Line metrics:")
        logging.debug("Height: min = {}, max = {}, avg = {}".format(self.min_line_gaps, self.max_line_gaps,
                                                                    self.avg_line_gaps))
        logging.debug("Lines with min height " + "|".join(map(str, self.lines_with_min_gap)))
        logging.debug("Lines with max height " + "|".join(map(str, self.lines_with_max_gap)))

        logging.debug("Frequency Distribution of Line Gaps")
        logging.debug(StatUtil.frequency_distribution(self.line_gaps))

        logging.debug("Outliers based on IQR")
        logging.debug(StatUtil.get_outliers_using_iqr(self.line_gaps))

        logging.debug("Outliers based on Z-Score")
        logging.debug(StatUtil.get_outliers_using_zscore(self.line_gaps))

        logging.debug("Frequency Distribution of Line's Left")
        logging.debug(StatUtil.frequency_distribution(self.line_min_left))

        logging.debug("Outliers of Line's left based on IQR")
        logging.debug(StatUtil.get_outliers_using_iqr(self.line_min_left))

        logging.debug("Outliers of Line's left based on Z-Score")
        logging.debug(StatUtil.get_outliers_using_zscore(self.line_min_left))

        logging.debug("Frequency Distribution of Line's Right")
        logging.debug(StatUtil.frequency_distribution(self.line_max_right))

        logging.debug("Outliers of Line's right based on IQR")
        logging.debug(StatUtil.get_outliers_using_iqr(self.line_max_right))

        logging.debug("Outliers of Line's right based on Z-Score")
        logging.debug(StatUtil.get_outliers_using_zscore(self.line_max_right))

    def __clean_and_sort_blocks(self):
        cutoff_box_height = 5
        self.noisy_blocks = list(filter(lambda x: x.bounding_box.height <= cutoff_box_height, self.all_blocks))
        self.all_blocks = list(filter(lambda x: x.bounding_box.height > cutoff_box_height, self.all_blocks))
        self.all_blocks.sort(key=lambda x: (x.bounding_box.bottom + x.bounding_box.top)/2, reverse=True)

    def __organize_lines_top_down(self):
        """
        Precondition: all_blocks are sorted in descending order of bottom
        """
        self.lines = []
        prev_line = None
        line = None
        while len(self.all_blocks) > 0:
            prev_line = line

            # top most block to start line
            line = Line()
            self.lines.append(line)

            topmost_word = self.all_blocks.pop(0)
            line.append_word(topmost_word)
            logging.debug("Beginning fresh line with word {}".format(topmost_word))

            # group words having same bottom in the same line
            if len(self.all_blocks) == 0:
                break
            next_word = self.all_blocks.pop(0)
            logging.debug("About to check the word for placing in current line {}".format(next_word))
            while line.bounding_box.bottom == next_word.bounding_box.bottom:
                line.append_word(next_word)
                logging.debug("Appended bottom matching word for placing in current line {}".format(next_word))
                next_word = None
                if len(self.all_blocks) > 0:
                    next_word = self.all_blocks.pop(0)
                else:
                    break

            # check if we have reached the end before proceeding further
            if len(self.all_blocks) == 0 and next_word is None:
                logging.debug("After adding bottom matching words, no more words left to add")
                break

            # now find out the next set of blocks
            # get blocks that have their midy inside the vertical limits of topmost word
            (bottom, top) = (topmost_word.bounding_box.bottom, topmost_word.bounding_box.top)
            logging.debug("About to look for blocks having their midbpoint between ({}, {})".format(bottom, top))
            current_index = 0
            while bottom <= next_word.bounding_box.midheight() <= top:
                logging.debug("Going to check next_word that is within the threshold {}".format(next_word))
                if line.get_word_in_x_pos(next_word) is not None:
                    # resolve conflicts with max top location
                    logging.debug("Ignoring current word as already there is a word in that position")
                    self.all_blocks.insert(current_index, next_word)
                    # TODO check if the currently added block should be considered disputed
                    current_index = current_index + 1
                else:
                    logging.debug("Appended threshold matching word for placing in current line {}".format(next_word))
                    line.append_word(next_word)
                    (bottom, top) = (min([bottom, next_word.bounding_box.bottom]), max([top, next_word.bounding_box.top]))
                    next_word = None
                if current_index < len(self.all_blocks):
                    next_word = self.all_blocks.pop(current_index)
                else:
                    break

            # bottom_threshold = topmost_word.bounding_box.bottom - (1.5 * topmost_word.bounding_box.height)
            # logging.debug("About to look for blocks matching bottom_threshold {}".format(bottom_threshold))
            # current_index = 0
            # while next_word.bounding_box.bottom >= bottom_threshold:
            #     logging.debug("Going to check next_word that is within the threshold {}".format(next_word))
            #     if line.get_word_in_x_pos(next_word):
            #         # resolve conflicts with max top location
            #         logging.debug("Ignoring current word as already there is a word in that position")
            #         self.all_blocks.insert(current_index, next_word)
            #         # TODO check if the currently added block should be considered disputed
            #         current_index = current_index + 1
            #     else:
            #         logging.debug("Appended threshold matching word for placing in current line {}".format(next_word))
            #         line.append_word(next_word)
            #         next_word = None
            #     if current_index < len(self.all_blocks):
            #         next_word = self.all_blocks.pop(current_index)
            #     else:
            #         break
                ##bottom_threshold = line.bounding_box.bottom - (2 * self.avg_block_height)

            # insert next_word back into block list
            if next_word is not None:
                logging.debug("Adding back next word to start the next line {}".format(next_word))
                self.all_blocks.insert(current_index, next_word)

            if len(self.all_blocks) == 0:
                logging.debug("After adding bottom threshold matching words, no more words left to add")
                break

            # TODO May be use statistical techniques or pattern analysis to derive this constant
            # to handle skew also handle top mismatch
            top_threshold = topmost_word.bounding_box.bottom - (0.75 * topmost_word.bounding_box.height)
            logging.debug("About to look for blocks matching top_threshold {}".format(top_threshold))
            current_index = 0
            next_word = self.all_blocks.pop(0)
            while next_word.bounding_box.top >= top_threshold:
                logging.debug("Going to check next_word that is within the top threshold {}".format(next_word))
                if line.get_word_in_x_pos(next_word) is not None:
                    logging.debug("Ignoring current word as already there is a word in that position")
                    self.all_blocks.insert(current_index, next_word)
                    current_index = current_index + 1
                else:
                    logging.debug(
                        "Appended top threshold matching word for placing in current line {}".format(next_word))
                    line.append_word(next_word)
                    line.append_disputed_block(next_word)
                    next_word = None
                if current_index < len(self.all_blocks):
                    next_word = self.all_blocks.pop(current_index)
                else:
                    break

            # insert next_word back into block list
            if next_word is not None:
                logging.debug("Adding back next word to start the next line {}".format(next_word))
                self.all_blocks.insert(current_index, next_word)

            # resolve blocks in dispute which are included in the previous line
            if prev_line is not None:
                evicted_blocks = line.resolve_disputes_by_mindpoint(prev_line)
                # evicted_blocks = line.resolve_disputes_by_sd(prev_line)
                # evicted_blocks = line.resolve_disputes_by_slope(prev_line)
                if len(evicted_blocks) > 0:
                    # insert evicted blocks in the right place of sorted block
                    self.__insert_blocks(evicted_blocks)

    def __insert_blocks(self, blocks_to_insert):
        blocks_to_insert.sort(key=lambda x: x.bounding_box.bottom, reverse=True)
        for block_index, block in enumerate(blocks_to_insert):
            last_inserted_index = 0
            index_to_insert = -1
            for i in range(last_inserted_index, len(self.all_blocks)):
                if self.all_blocks[i].bounding_box.bottom <= block.bounding_box.bottom:
                    index_to_insert = i
                    break
            if index_to_insert != -1:
                self.all_blocks.insert(index_to_insert, block)
            else:
                # add at the end, the current block and the remaining
                self.all_blocks.append(block)
                block_index = block_index + 1
                while block_index < len(blocks_to_insert):
                    self.all_blocks.append(blocks_to_insert[block_index])
                    block_index = block_index + 1
                break

    def __organize_vertical_sections(self):
        self.vertical_sections = []
        gap_index = 0
        # TODO arrive at this threshold more statistically rather than randomly
        gap_threshold = self.avg_line_gaps + (0.5 * self.avg_block_height)
        while gap_index < len(self.line_gaps):
            section = Section()
            self.vertical_sections.append(section)

            # add the current line
            section.append_line(self.lines[gap_index])

            # depending on the current gap, either add lines in current section or as separate sections
            gap = self.line_gaps[gap_index]
            if gap > gap_threshold:
                gap_index = gap_index + 1
                continue

            while (gap <= gap_threshold and gap_index < len(self.line_gaps)):
                # add line to current section
                section.append_line(self.lines[gap_index + 1])

                gap_index = gap_index + 1
                if (gap_index < len(self.line_gaps)):
                    gap = self.line_gaps[gap_index]
                else:
                    break
            # TODO it was observed that wrongly recognized lines have abnormal values of the gaps. Leverage this to clean up the lines. It was also due to the presence of noise blocks in the line
            # TODO also for mismatched /contentious block see which adjacent lines it fits better by seeing the closest distance to the top line (connecting the midpoints of word blocks in above line) or bottome line
            gap_index = gap_index + 1

    def __identify_tables_in_sections(self):
        min_lines_for_table = 2
        for sec_num, section in enumerate(self.vertical_sections):
            # if section has only one line then identify them as paragraph
            if len(section.lines) < min_lines_for_table:
                section.create_add_paragraph(section.lines, 0, len(section.lines) - 1)
                continue

            # start from topmost line and check for tables in the section
            tables = section.extract_table()
            section_line_offset = 0
            for (table_start_line_index, table_end_line_index, table) in tables:
                if table_start_line_index == -1:
                    # no tables in section, hence add all lines as paragraph
                    section.create_add_paragraph(section.lines, 0, len(section.lines) - 1)
                    break
                else:
                    if table_start_line_index > section_line_offset:
                        # table is not starting from first line. so create paragraph out of the residual lines on top
                        lines_np = np.array(section.lines)
                        para_lines = lines_np[section_line_offset: table_start_line_index].tolist()
                        section.create_add_paragraph(para_lines, section_line_offset, table_start_line_index - 1)

                    # add the extracted table to section
                    section.append_table(table, table_start_line_index, table_end_line_index)
                    section_line_offset = table_end_line_index + 1

            if 0 < section_line_offset < (len(section.lines) - 1):
                # We have extracted a table but table is not ending till the last line. so create paragraph out of
                # the residual lines on bottom
                lines_np = np.array(section.lines)
                para_lines = lines_np[section_line_offset:len(section.lines)].tolist()
                section.create_add_paragraph(para_lines, section_line_offset, len(section.lines) - 1)

    def __str__(self):
        dest_str = ""
        # Print word by word
        # for block in self.all_blocks:
        #     dest_str = dest_str + " " + str(block)

        # Print line by line
        # for line_num, line in enumerate(self.lines):
        #     if line_num != 0:
        #         dest_str = dest_str + "\n"
        #     dest_str = dest_str + "Line " + str(line_num) + ": " + str(line)

        for sec_num, section in enumerate(self.vertical_sections):
            if sec_num != 0:
                dest_str = dest_str + "\n"
            dest_str = dest_str + "Section " + str(sec_num) + ": " + str(section)

        return dest_str


class Section:
    def __init__(self):
        self.lines = []
        self.paragraphs = []
        self.tables = []

    def append_line(self, line):
        self.lines.append(line)

    def __str__(self):
        # Line by line printing
        # dest_str = ""
        # for line_num, line in enumerate(self.lines):
        #     if line_num != 0:
        #         dest_str = dest_str + "\n"
        #     dest_str = dest_str + "Line " + str(line_num) + ": " + str(line)

        # Print paragraphs and tables
        dest_str = ""
        # TODO for now printing paragraphs then tables. Later use their respective start indices to list them in the
        #  order they occur
        if len(self.paragraphs) > 0:
            dest_str = dest_str + "Paragraphs:"
            for para_num, para in enumerate(self.paragraphs):
                dest_str = dest_str + "\n" + "Para " + str(para_num) + ":\n" + str(para) + "\n"

        if len(self.tables) > 0:
            dest_str = dest_str + "\n Tables:"
            for table_num, table in enumerate(self.tables):
                dest_str = dest_str + "\n" + "Table " + str(table_num) + ":\n" + str(table)

        return dest_str

    def extract_table(self):
        min_lines_for_table = 2
        # minimum no. of columns that we look to identify as tables from no. of gaps = min_cols_in_table - 1
        min_cols_in_table = 2

        if len(self.lines) <= min_lines_for_table:
            return [(-1, -1, None)]

        # tables collection to hold one or more tables extracted from current section
        tables = []

        current_line_index = 0
        current_line = self.lines[current_line_index]
        gaps_in_line = current_line.get_gaps_in_line()

        # it might be possible that there are no gaps in the line, reach till you get non-zero gaps
        while gaps_in_line is None and current_line_index < len(self.lines) - 1:
            current_line_index = current_line_index + 1
            current_line = self.lines[current_line_index]
            gaps_in_line = current_line.get_gaps_in_line()

        table_start_line_index = current_line_index
        table_end_line_index = current_line_index
        while current_line_index < len(self.lines) - 1:
            next_line = self.lines[current_line_index + 1]
            matching_gaps = next_line.get_intersecting_gaps(gaps_in_line)

            if len(matching_gaps) < len(gaps_in_line) and (
                    current_line_index - table_start_line_index + 1) >= min_lines_for_table:
                # if number of matched columns (gaps) is reducing after accumulating min lines for table
                table_lines = np.array(self.lines)[table_start_line_index: current_line_index + 1].tolist()
                table = Table.create_table(table_lines, gaps_in_line, table_start_line_index, current_line_index)
                tables.append((table_start_line_index, current_line_index, table))

                # Rebase the table start to current index and start exploring down
                current_line_index = current_line_index + 1
                table_start_line_index = current_line_index
                table_end_line_index = current_line_index
                current_line = next_line
                gaps_in_line = current_line.get_gaps_in_line()

            elif len(matching_gaps) < (min_cols_in_table - 1):
                # No matching gaps. decide to either construct table from identified lines or restart table
                # identification
                if (current_line_index - table_start_line_index + 1) > min_lines_for_table:
                    table_lines = np.array(self.lines)[table_start_line_index: current_line_index + 1].tolist()
                    table = Table.create_table(table_lines, gaps_in_line, table_start_line_index, current_line_index)
                    tables.append((table_start_line_index, current_line_index, table))

                # Rebase the table start to current index and start exploring down
                current_line_index = current_line_index + 1
                table_start_line_index = current_line_index
                table_end_line_index = current_line_index
                current_line = next_line
                gaps_in_line = current_line.get_gaps_in_line()
            else:
                # there are matching gaps. start accumulating further rows
                current_line_index = current_line_index + 1
                table_end_line_index = current_line_index
                current_line = next_line
                gaps_in_line = matching_gaps

        # add lines which are matched
        if table_start_line_index < table_end_line_index:
            table_lines = np.array(self.lines)[table_start_line_index: table_end_line_index + 1].tolist()
            table = Table.create_table(table_lines, gaps_in_line, table_start_line_index, table_end_line_index)
            tables.append((table_start_line_index, table_end_line_index, table))
        return tables

    def create_add_paragraph(self, lines, start_index_incl, end_index_incl):
        para = Paragraph(lines, start_index_incl, end_index_incl)
        self.paragraphs.append(para)

    def append_table(self, table, start_index_incl, end_index_incl):
        self.tables.append(table)


class Paragraph:
    """
    Characteristics of a Paragraph
    1. Gaps between the words are more or less uniform
    2. Gaps between words are in random locations, especially when the gaps are more. This is critical to differentiate between
    3. Except for the last line, the rest of the lines are almost filled or have most of the gaps on left end of line or right end of line
    """
    def __init__(self, lines, start_index_incl, end_index_incl):
        self.lines = lines
        self.start_index_in_sec = start_index_incl
        self.end_index_in_sec = end_index_incl

    def __str__(self):
        dest_str = "Start Index:{}, End Index: {}".format(self.start_index_in_sec, self.end_index_in_sec)
        for line_num, line in enumerate(self.lines):
            dest_str = dest_str + "\n" + str(line)
        return dest_str


class Table:
    def __init__(self, table_lines, start_line_index, end_line_index):
        self.lines = table_lines
        self.start_index_in_sec = start_line_index
        self.end_index_in_sec = end_line_index
        self.rows = []

    @classmethod
    def create_table(cls, table_lines, gaps_in_line, start_line_index, end_line_index):
        table = Table(table_lines, start_line_index, end_line_index)

        for line in table_lines:
            row = Row.create_row(line, gaps_in_line)
            table.append_row(row)

        return table

    def append_row(self, row):
        self.rows.append(row)

    def __str__(self):
        return "\n".join(map(str, self.rows))


class Row:
    def __init__(self):
        self.cells = []

    @classmethod
    def create_row(cls, line, gaps_in_line):
        row = Row()
        start_gap = None
        for gap in gaps_in_line:
            if start_gap is None:
                words_before_gap = line.get_blocks_before_gap(gap)
            else:
                words_before_gap = line.get_blocks_btw_gaps(start_gap, gap)

            if len(words_before_gap) == 0:
                cell = Cell()
            else:
                cell = Cell(words_before_gap)
            row.append_cell(cell)
            start_gap = gap

        # append last column
        last_gap = gaps_in_line[-1]
        words_after_gap = line.get_blocks_after_gap(last_gap)
        if len(words_after_gap) == 0:
            cell = Cell()
        else:
            cell = Cell(words_after_gap)
        row.append_cell(cell)

        return row

    def append_cell(self, cell):
        self.cells.append(cell)

    def __str__(self):
        return "\t|".join(map(str, self.cells))


class Cell:
    def __init__(self, words=None):
        if words is not None:
            self.words = words
        else:
            self.words = []

    def __str__(self):
        if len(self.words) == 0:
            return ""
        dest_str = ""
        for word in self.words:
            dest_str = dest_str + word.text + " "
        return dest_str.strip()


class Form:
    def __init__(self):
        pass


class Line:
    def __init__(self):
        self.words = []
        self.bounding_box = None
        self.text = ""
        self.disputed_blocks = []

    def append_word(self, word):
        self.words.append(word)
        if self.bounding_box is None:
            self.bounding_box = word.bounding_box.clone()
        else:
            self.bounding_box.append(word.bounding_box)
        self.words.sort(key=lambda x: x.bounding_box.left)
        self.text = ""
        for word in self.words:
            self.text = self.text + " " + word.text
        self.text = self.text.strip()

    def remove_word(self, word_to_remove):
        try:
            self.words.remove(word_to_remove)
            self.words.sort(key=lambda x: x.bounding_box.left)
            self.text = ""
            self.bounding_box = None
            for word in self.words:
                self.text = self.text + " " + word.text
                if self.bounding_box is None:
                    self.bounding_box = word.bounding_box.clone()
                else:
                    self.bounding_box.append(word.bounding_box)
                self.text = self.text.strip()
        except ValueError as e:
            pass

    def append_disputed_block(self, word_block):
        self.disputed_blocks.append(word_block)

    def remove_disputed_block(self, word_block):
        try:
            self.disputed_blocks.remove(word_block)
        except ValueError as e:
            return -1

    def get_word_in_x_pos(self, word_to_check):
        for word in self.words:
            if (
                    word.bounding_box.left <= word_to_check.bounding_box.left < word.bounding_box.right) or (
                    word.bounding_box.left <= word_to_check.bounding_box.right < word.bounding_box.right) or (
                    word.bounding_box.left <= word_to_check.bounding_box.left and word_to_check.bounding_box.right <= word.bounding_box.right) or (
                    word_to_check.bounding_box.left <= word.bounding_box.left and word_to_check.bounding_box.right >= word.bounding_box.right):
                # let us allow blocks to overlap marginally
                mid_y = (word_to_check.bounding_box.top + word_to_check.bounding_box.bottom) / 2
                if not (word.bounding_box.bottom <= mid_y <= word.bounding_box.top):
                    # The current word is not containing the midpoint of the word to check. Both can't be in the same line
                    return word
        return None

    def get_gaps_in_line(self):
        gaps = []
        for i in range(len(self.words) - 1):
            current_box = self.words[i].bounding_box
            next_box = self.words[i + 1].bounding_box

            gap = BoundingBox.box_between(current_box, next_box)
            if gap is not None:
                gaps.append(gap)
        return gaps

    def get_intersecting_gaps(self, gaps_to_match):
        intersection_gaps = []
        gaps_in_line = self.get_gaps_in_line()
        if len(gaps_to_match) <= 0 or len(gaps_in_line) <= 0:
            return intersection_gaps

        for gap_to_match in gaps_to_match:
            last_intersection = None
            for gap_in_line in gaps_in_line:
                if gap_in_line.left > gap_to_match.right:
                    # we have already come to the right side of gap_to_match
                    break
                intersection = BoundingBox.get_intersection(gap_to_match, gap_in_line)
                if intersection is not None:
                    # though we have found the intersection, check if there is any other intersection still
                    last_intersection = intersection
            if last_intersection is not None:
                intersection_gaps.append(last_intersection)

        return intersection_gaps

    def get_blocks_before_gap(self, gap):
        """
        Pre-condition: all words inside the line are arranged in sorted way based on bounding_box.left
        """
        blocks_before_gap = [word for word in self.words if word.bounding_box.right <= gap.left]
        return blocks_before_gap

    def get_blocks_after_gap(self, gap):
        """
        Pre-condition: all words inside the line are arranged in sorted way based on bounding_box.left
        """
        blocks_after_gap = [word for word in self.words if word.bounding_box.left >= gap.right]
        return blocks_after_gap

    def get_blocks_btw_gaps(self, start_gap, end_gap):
        blocks_btw_gap = [word for word in self.words if start_gap.right <= word.bounding_box.left <= end_gap.left]
        return blocks_btw_gap

    def get_centroid_of_words(self, block_to_exclude=None):
        centroids = []
        for word in self.words:
            if block_to_exclude is not None:
                if word == block_to_exclude:
                    continue
            centroids.append(word.bounding_box.get_centroid())
        return centroids

    def resolve_disputes_by_sd(self, prev_line):
        evicted_blocks = []
        if len(prev_line.disputed_blocks) < 2 or len(self.words) < 2:
            # all blocks are in exact straight line, so no dispute
            return evicted_blocks

        # get centroid of all words in prev_line and current line
        prev_centroid_of_all_words = prev_line.get_centroid_of_words()
        prev_avg_centroid = statistics.mean([y for (x, y) in prev_centroid_of_all_words])
        prev_stdev_of_all_words = statistics.stdev([y for (x, y) in prev_centroid_of_all_words])

        while len(prev_line.disputed_blocks) > 0:
            block_in_dispute = prev_line.disputed_blocks[0]
            # calculate standard deviation without the disputed block
            prev_centroid_of_rest_of_words = prev_line.get_centroid_of_words(block_in_dispute)
            prev_stdev_of_rest_of_words = statistics.stdev([y for (x, y) in prev_centroid_of_rest_of_words])

            # temporarily add dispute block to current line replacing the block that might have added in its position
            word_to_evict = self.get_word_in_x_pos(block_in_dispute)
            if word_to_evict is not None:
                self.remove_word(word_to_evict)
            self.append_word(block_in_dispute)

            curr_centroid_of_all_words = self.get_centroid_of_words()
            curr_avg_centroid = statistics.mean([y for (x, y) in curr_centroid_of_all_words])
            curr_stdev_of_all_words = statistics.stdev([y for (x, y) in curr_centroid_of_all_words])
            curr_centroid_of_rest_of_words = self.get_centroid_of_words(block_in_dispute)
            curr_stdev_of_rest_of_words = statistics.stdev([y for (x, y) in curr_centroid_of_rest_of_words])

            # if sd reduces then remove from disputed
            prev_sd_diff = abs(prev_stdev_of_all_words - prev_stdev_of_rest_of_words)
            curr_sd_diff = abs(curr_stdev_of_all_words - curr_stdev_of_rest_of_words)
            if curr_sd_diff < prev_sd_diff:
                # disputed block belongs to current line, go ahead
                prev_line.remove_word(block_in_dispute)
                if word_to_evict is not None:
                    evicted_blocks.append(word_to_evict)
            else:
                # disputed block belons to prev line, roll back our changes to current line
                self.remove_word(block_in_dispute)
                if word_to_evict is not None:
                    self.append_word(word_to_evict)

            prev_line.remove_disputed_block(block_in_dispute)

        return evicted_blocks

    def resolve_disputes_by_mindpoint(self, prev_line):
        evicted_blocks = []
        while len(prev_line.disputed_blocks) > 0:
            block_in_dispute = prev_line.disputed_blocks[0]
            # remove and add it back to the right line
            prev_line.remove_word(block_in_dispute)

            prev_mid_y = (prev_line.bounding_box.top + prev_line.bounding_box.bottom) / 2
            this_mid_y = (self.bounding_box.top + self.bounding_box.bottom) / 2
            word_mid_y = (block_in_dispute.bounding_box.top + block_in_dispute.bounding_box.bottom) / 2

            dist_to_prev = abs(prev_mid_y - word_mid_y)
            dist_to_this = abs(this_mid_y - word_mid_y)

            if dist_to_prev < dist_to_this:
                prev_line.append_word(block_in_dispute)
            elif dist_to_prev > dist_to_this:
                # check if any word has to be evicted to accommodate the current word
                word_to_evict = self.get_word_in_x_pos(block_in_dispute)
                if word_to_evict is not None:
                    self.remove_word(word_to_evict)
                    evicted_blocks.append(word_to_evict)
                self.append_word(block_in_dispute)

            # remove from disputed
            prev_line.remove_disputed_block(block_in_dispute)
        return evicted_blocks

    def __compute_slope(self, left_point, right_point):
        (x1, y1) = left_point
        (x2, y2) = right_point

        if (x2 == x1):
            print("Wander now ")
            return 0
        return (y2 - y1) / (x2 - x1)

    def get_centroid_of_blocks_before(self, given_word):
        centroids = []
        (given_x, given_y) = given_word.bounding_box.get_centroid()
        for word in self.words:
            (x, y) = word.bounding_box.get_centroid()
            if x <= given_x:
                centroids.append((x,y))
            if word == given_word:
                break
        return centroids

    def get_centroid_of_blocks_after(self, given_word):
        centroids = []
        (given_x, given_y) = given_word.bounding_box.get_centroid()
        for word in self.words:
            (x, y) = word.bounding_box.get_centroid()
            if x >= given_x:
                centroids.append((x,y))
        return centroids

    def resolve_disputes_by_slope(self, prev_line):
        # disputed block belongs to the line where the change in slope is minimum which in a way signifies the block
        # is fitting better with that line

        evicted_blocks = []
        if len(self.words) < 2 or len(prev_line.words) < 2:
            # all blocks are in exact straight line, so no dispute
            return evicted_blocks

        while len(prev_line.disputed_blocks) > 0:
            block_in_dispute = prev_line.disputed_blocks[0]

            # get centroids before and after current block
            prev_line_before_blocks_centroid = prev_line.get_centroid_of_blocks_before(block_in_dispute)
            prev_line_after_blocks_centroid = prev_line.get_centroid_of_blocks_after(block_in_dispute)

            prev_line_slope_diff_before_block = None
            prev_line_slope_diff_after_block = None
            if len(prev_line_before_blocks_centroid) >= 3:
                # we need min 3 blocks to compute change in slope
                dispute_index = len(prev_line_before_blocks_centroid) - 1
                slope_before = self.__compute_slope(prev_line_before_blocks_centroid[dispute_index],
                                                    prev_line_before_blocks_centroid[dispute_index - 1])
                slope_one_before = self.__compute_slope(prev_line_before_blocks_centroid[dispute_index - 1],
                                                        prev_line_before_blocks_centroid[dispute_index - 2])
                prev_line_slope_diff_before_block = slope_before - slope_one_before

            if len(prev_line_after_blocks_centroid) >= 3:
                # we need min 3 blocks to compute change in slope
                dispute_index = 0
                slope_after = self.__compute_slope(prev_line_after_blocks_centroid[dispute_index],
                                                   prev_line_after_blocks_centroid[dispute_index + 1])
                slope_one_after = self.__compute_slope(prev_line_after_blocks_centroid[dispute_index + 1],
                                                       prev_line_after_blocks_centroid[dispute_index + 2])
                prev_line_slope_diff_after_block = slope_one_after - slope_after

            # temporarily add dispute block to current line replacing the block that might have added in its position
            word_to_evict = self.get_word_in_x_pos(block_in_dispute)
            if word_to_evict is not None:
                self.remove_word(word_to_evict)
            self.append_word(block_in_dispute)

            # get centroids before and after current block
            curr_line_before_blocks_centroid = self.get_centroid_of_blocks_before(block_in_dispute)
            curr_line_after_blocks_centroid = self.get_centroid_of_blocks_after(block_in_dispute)

            curr_line_slope_diff_before_block = None
            curr_line_slope_diff_after_block = None
            if len(curr_line_before_blocks_centroid) >= 3:
                # we need min 3 blocks to compute change in slope
                dispute_index = len(curr_line_before_blocks_centroid) - 1
                slope_before = self.__compute_slope(curr_line_before_blocks_centroid[dispute_index],
                                                    curr_line_before_blocks_centroid[dispute_index - 1])
                slope_one_before = self.__compute_slope(curr_line_before_blocks_centroid[dispute_index - 1],
                                                        curr_line_before_blocks_centroid[dispute_index - 2])
                curr_line_slope_diff_before_block = slope_before - slope_one_before

            if len(curr_line_after_blocks_centroid) >= 3:
                # we need min 3 blocks to compute change in slope
                dispute_index = 0
                slope_after = self.__compute_slope(curr_line_after_blocks_centroid[dispute_index],
                                                   curr_line_after_blocks_centroid[dispute_index + 1])
                slope_one_after = self.__compute_slope(curr_line_after_blocks_centroid[dispute_index + 1],
                                                       curr_line_after_blocks_centroid[dispute_index + 2])
                curr_line_slope_diff_after_block = slope_one_after - slope_after

            # handle various cases when both lines have all the slope differences
            dispute_in_favour_of_prev_line = True
            if prev_line_slope_diff_before_block is not None and prev_line_slope_diff_after_block is not None and curr_line_slope_diff_before_block is not None and curr_line_slope_diff_after_block is not None:
                # case 1: slope diff in prev line is less than that in curr_line, dispute in favour of prev line, so rollback
                if prev_line_slope_diff_before_block <= curr_line_slope_diff_before_block and prev_line_slope_diff_after_block <= curr_line_slope_diff_after_block:
                    dispute_in_favour_of_prev_line = True
                # case 2: slope diff in prev line is greater than that in curr_line, dispute in favour of current line, so commit
                elif prev_line_slope_diff_before_block > curr_line_slope_diff_before_block and prev_line_slope_diff_after_block > curr_line_slope_diff_after_block:
                    dispute_in_favour_of_prev_line = False
                else:
                    # case 3: Any one side is more
                    slope_diff_before = prev_line_slope_diff_before_block - curr_line_slope_diff_before_block
                    slope_diff_after = prev_line_slope_diff_after_block - curr_line_slope_diff_after_block
                    if abs(slope_diff_before) <= abs(slope_diff_after):
                        # go with min slope on the left hand side
                        dispute_in_favour_of_prev_line = slope_diff_before < 0
                    else:
                        # go with min slope on the right hand side
                        dispute_in_favour_of_prev_line=  slope_diff_after < 0
            else:
                # we have got fewer slope diff to arrive at conclusion
                if prev_line_slope_diff_before_block is None or curr_line_slope_diff_before_block is None:
                    # we cant rely on left hand side. Use right hand side
                    if prev_line_slope_diff_after_block is not None and curr_line_slope_diff_after_block is not None:
                        slope_diff_after = prev_line_slope_diff_after_block - curr_line_slope_diff_after_block
                        dispute_in_favour_of_prev_line=  slope_diff_after < 0
                    else:
                        # TODO Handle this tricky situation, atleast warn
                        dispute_in_favour_of_prev_line = True
                else:
                    # resolve based on left hand side
                    slope_diff_before = prev_line_slope_diff_before_block - curr_line_slope_diff_before_block
                    dispute_in_favour_of_prev_line = slope_diff_before < 0

            if dispute_in_favour_of_prev_line is True:
                self.remove_word(block_in_dispute)
                if word_to_evict is not None:
                    self.append_word(word_to_evict)
            else:
                prev_line.remove_word(block_in_dispute)
                self.append_word(block_in_dispute)
                if word_to_evict is not None:
                    evicted_blocks.append(word_to_evict)

            prev_line.remove_disputed_block(block_in_dispute)

        return evicted_blocks

    def __str__(self):
        return self.text + " " + str(self.bounding_box)


class Word:
    """
    Leaf level text blocks
    """

    def __init__(self, ocr_word, ocr_line, line_index, ocr_block, block_index):
        self.bounding_box = BoundingBox(ocr_word.get("bounding_box"))
        self.text = ocr_word.get("text")
        self.line_text = ocr_line.get("text")
        self.line_index = line_index
        self.line_bounding_box = BoundingBox(ocr_line.get("bounding_box"))
        self.block_index = block_index
        if ocr_block.get("bounding_box") is not None:
            self.block_bounding_box = BoundingBox(ocr_block.get("bounding_box"))

    def __str__(self):
        return self.text + " " + str(self.bounding_box)


class BoundingBox:
    """Rectangle in a 2D Plane with origin in bottom left corner of the page"""

    def __init__(self, bounding_box):
        (self.top_left_x, self.top_left_y, self.top_right_x, self.top_right_y, self.bottom_right_x, self.bottom_right_y,
         self.bottom_left_x, self.bottom_left_y) = tuple(bounding_box)
        self.__compute_dimensions()

    def clone(self):
        new_box = (
            self.top_left_x, self.top_left_y, self.top_right_x, self.top_right_y, self.bottom_right_x,
            self.bottom_right_y, self.bottom_left_x, self.bottom_left_y)
        new_box_as_array = list(new_box)
        return BoundingBox(new_box_as_array)

    def __compute_dimensions(self):
        self.top = max(self.top_left_y, self.top_right_y)
        self.bottom = min(self.bottom_left_y, self.bottom_right_y)
        self.left = min(self.top_left_x, self.bottom_left_x)
        self.right = max(self.top_right_x, self.bottom_right_x)
        self.width = self.right - self.left
        self.height = self.top - self.bottom

    def is_in_horizontal_line(self, box_to_check, avg_block_height):
        """If bottom of one bounding box is between the bottom and top of other"""
        return (box_to_check.bottom >= self.bottom and box_to_check.bottom <= self.top) or (
                self.bottom >= box_to_check.bottom and self.bottom <= box_to_check.top) or (
                   (box_to_check.bottom <= (
                           self.top + avg_block_height) and box_to_check.top <= self.top + avg_block_height + box_to_check.height)) or (
                       box_to_check.top <= (self.top - avg_block_height) and box_to_check.bottom >= (
                       self.top - avg_block_height - box_to_check.height))

    def get_centroid(self):
        return ((self.left + self.right) / 2, (self.top + self.bottom) / 2)

    def is_in_vertical_line(self, box_to_check):
        """If left / right of one bounding box is between the left / right of other"""
        return (box_to_check.left >= self.left and box_to_check.left <= self.right) or (
                self.left >= box_to_check.left and self.left <= box_to_check.right)

    def is_overlapping(self, box_to_check):
        """If the box_to_check is cutting the current box"""
        return ((box_to_check.top >= self.bottom and box_to_check.bottom < self.bottom) or
                (box_to_check.bottom >= self.bottom and box_to_check.bottom < self.top)) and \
               ((box_to_check.left >= self.left and box_to_check.left <= self.right) or
                (box_to_check.right >= self.left and box_to_check.right <= self.right))

    def append(self, box_to_add):
        """Extend the bounding box to accommodate given box"""
        self.top_left_x = min(self.top_left_x, box_to_add.top_left_x)
        self.top_left_y = max(self.top_left_y, box_to_add.top_left_y)
        self.top_right_x = max(self.top_right_x, box_to_add.top_right_x)
        self.top_right_y = max(self.top_right_y, box_to_add.top_right_y)
        self.bottom_right_x = max(self.bottom_right_x, box_to_add.bottom_right_x)
        self.bottom_right_y = min(self.bottom_right_y, box_to_add.bottom_right_y)
        self.bottom_left_x = min(self.bottom_left_x, box_to_add.bottom_left_x)
        self.bottom_left_y = min(self.bottom_left_y, box_to_add.bottom_left_y)
        self.__compute_dimensions()

    def __str__(self):
        return "[top: {}, left: {}, bottom: {}, right: {}, width: {}, height: {}, (x1,y1,x2,y2,x3,y3,x4,y4): ({},{}," \
               "{},{},{},{},{},{})]".format(
            self.top, self.left,
            self.bottom, self.right,
            self.width, self.height, self.top_left_x, self.top_left_y, self.top_right_x, self.top_right_y,
            self.bottom_right_x, self.bottom_right_y,
            self.bottom_left_x, self.bottom_left_y)

    def cut_horizontally(self, left, right):
        cut_box = (
            left, self.top_left_y, right, self.top_right_y, right, self.bottom_right_y, left, self.bottom_left_y)
        new_box_as_array = list(cut_box)
        return BoundingBox(new_box_as_array)

    def midheight(self):
        return (self.top + self.bottom)/2

    @classmethod
    def box_between(cls, current_box, next_box):
        if current_box.right >= next_box.left:
            return None
        new_box = (
            current_box.top_right_x, current_box.top_right_y, next_box.top_left_x, next_box.top_left_y,
            next_box.bottom_left_x, next_box.bottom_left_y, current_box.bottom_right_x, current_box.bottom_left_y)
        new_box_as_array = list(new_box)
        return BoundingBox(new_box_as_array)

    @classmethod
    def get_intersection(cls, gap_to_match, gap_in_line):
        """intersection in x-axis"""
        if gap_to_match is None or gap_in_line is None:
            return None

        if gap_to_match.right < gap_in_line.left or gap_in_line.right < gap_to_match.left:
            # mutually exclusive
            return None
        left = max([gap_to_match.left, gap_in_line.left])
        right = min([gap_to_match.right, gap_in_line.right])

        cut1 = gap_to_match.cut_horizontally(left, right)
        cut2 = gap_in_line.cut_horizontally(left, right)

        # join the 2 cuts
        cut1.append(cut2)
        return cut1


OutputFormatter.register(DomOutputFormatter)


def test_special_chars_only():
    print("~ is ", PageDocument.is_only_special_chars("."))
    print("abc is ", PageDocument.is_only_special_chars("_~.'\""))


if __name__ == "__main__":
    test_special_chars_only()
