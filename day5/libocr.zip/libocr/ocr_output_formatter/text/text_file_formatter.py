INCHES_TO_POINT = 72

class TextFileFormatter:
    """
    Prints OCR response to the text file, line by line or word by word depending on config
    """

    def output_ocr_result(self, ocr_result, output_config=None):
        """
        @param ocr_result: response obtained from OCR service
        @param output_config: configuration values. This
        depends on configuration key "output_word_by_word". If this config is True, contents are printed word by word
        else line by line. Also depends on "file_name" key to which output is written
        @raise ValueError: in case no file_name key is passed in config
        """
        # Open the file to add contents of all pages in the ocr_result
        outfile = output_config.get("file_name")
        if not outfile:
            raise ValueError("No file_name parameter passed in output_config")
        f = open(outfile, "w")

        # for text_result in get_printed_text_results.recognition_results:
        for text_result in ocr_result:
            for block in text_result["blocks"]:
                for line in block["lines"]:
                    if output_config["output_word_by_word"]:
                        for word in line["words"]:
                            self.__write_contents(word, f, output_config)
                    else:
                        self.__write_contents(line, f, output_config)
                    print()
        f.close()

    def __write_contents(self, content_obj, f, output_config):
        f.write(content_obj["text"])
        f.write("\n")
        f.write(str(content_obj["bounding_box"]))
        f.write("\n")
