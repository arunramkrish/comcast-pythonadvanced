from libocr.output_formatter import OutputFormatter
import json
import logging
import statistics
import re
import numpy as np
from libocr.util.stat_util import StatUtil


class DictOutputFormatter:

    def output_ocr_result(self, ocr_result, output_config={}):
        if output_config.get("pages") is None:
            output_config["pages"] = []
        if ocr_result is not None:
            for page in ocr_result:
                output_config["pages"].append(page)

        if output_config["current_page"] == output_config["total_pages"] - 1:
            # we have reached the last page
            if output_config.get("file_name") is not None:
                with open(output_config.get("file_name"), 'w') as file:
                    file.write(
                        json.dumps(output_config.get("pages"), default=lambda o: o.__dict__, sort_keys=True, indent=2))