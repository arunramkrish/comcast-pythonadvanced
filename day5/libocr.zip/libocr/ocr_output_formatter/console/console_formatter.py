from libocr.output_formatter import OutputFormatter


class ConsoleFormatter:
    """
    Prints OCR response on the console, line by line or word by word depending on config
    """

    def output_ocr_result(self, ocr_result, output_config=None):
        """
        @param ocr_result: response obtained from OCR service @param output_config: configuration values. This
        depends on configuration key "output_word_by_word". If this config is True, contents are printed word by word
        else line by line
        """
        for text_result in ocr_result:
            for block in text_result["blocks"]:
                for line in block["lines"]:
                    if output_config["output_word_by_word"]:
                        for word in line["words"]:
                            self.__write_contents(word, output_config)
                    else:
                        self.__write_contents(line, output_config)
                    print()

    def __write_contents(self, content_obj, output_config):
        print(content_obj["text"] + "\n")
        print(str(content_obj["bounding_box"]) + "\n")


OutputFormatter.register(ConsoleFormatter)
