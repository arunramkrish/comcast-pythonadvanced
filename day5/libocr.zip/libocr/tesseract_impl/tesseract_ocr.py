from pdf2image import convert_from_path
from PIL import Image
from PyPDF2 import PdfFileReader, PdfFileWriter
import pytesseract
import platform
import logging
import cv2
import re
from libocr.ocr_provider import OcrProvider
from libimageproc import img_processor_factory
from libimageproc.img_processor import ImgProcessor
from libocr.util import geometric_util


TESSDATA_DIR_WINDOWS = "F:/Finstinct_Data/tessdata"
# TESSDATA_DIR_LINUX = "/root/finstinct/tessdata"
TESSDATA_DIR_LINUX = "/home/ubuntu/finstinct/tessdata"

class TesseractOcrProvider:
	"""
	Virtually implements OcrProvider interface using Tesseract Library. Takes an image and returns a
	JSON containing texts along with their bounding boxes with coorinates and dimensions with reference to the image
	"""

	def __init__(self):
		self.computervision_client = None

	def supports_multipage_pdf(self):
		return True

	def get_supported_output_formats(self):
		return ["pdf"]

	def get_processors_before_ocr(self):
		# not using"dewarp"
		# TODO Move this list to config
		# return ["deskew", "rotate"]
		return []

	def get_tess_config(self, output_config):
		tessdata_dir = output_config.get("tessdata_dir")

		if tessdata_dir is None:
			sys = platform.system()
			if sys == "Windows":
				tessdata_dir = TESSDATA_DIR_WINDOWS
			else:
				tessdata_dir = TESSDATA_DIR_LINUX
		tess_config = r'--tessdata-dir "' + tessdata_dir + '"'
		return tess_config


	def preprocess_file(self, file_name, output_config):
		# load the image and convert it to grayscale
		# image = cv2.imread(file_name)
		# # gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
		# gray = deskew.deskewImage(image)
		# if output_config.get("standalone") is True:
		# 	cv2.imshow("Image", gray)
		#
		# # check to see if we should apply thresholding to preprocess the
		# # image
		# if output_config.get("preprocess2") == "thresh":
		# 	gray = cv2.threshold(gray, 0, 255,
		# 						 cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
		#
		# # make a check to see if median blurring should be done to remove
		# # noise
		# if output_config.get("preprocess1") == "blur":
		# 	gray = cv2.medianBlur(gray, 3)
		#
		# # write the grayscale image to disk as a temporary file so we can
		# # apply OCR to it
		# filename = "{}.png".format(os.getpid())
		# cv2.imwrite(filename, gray)
		#
		# # load the image as a PIL/Pillow image, apply OCR, and then delete
		# # the temporary file
		# # text = pytesseract.image_to_data(Image.open(filename))
		# # text = pytesseract.run_and_get_output(Image.open(filename))
		# # os.remove(filename)
		img = Image.open(file_name)
		return img

	def ocr_to_pdf(self, pdf_file, config):
		# Part #1 : Converting PDF to images

		# Store all the pages of the PDF in a variable
		dpi = config.get("dpi") if config.get("dpi") else 300
		fmt = config.get("img_fmt") if config.get("img_fmt") else "jpg"
		logging.info("Converting PDF file {} to images with dpi {} and format {}".format(pdf_file, str(dpi), fmt))
		pages = convert_from_path(pdf_file, dpi=dpi, fmt=fmt)
		logging.info("Successfully converted PDF file {} to {} images ".format(pdf_file, str(len(pages))))

		# Creating a text file to write the output
		if config["file_name"] is None:
			config["file_name"] = pdf_file + "_ocred.pdf"

		# list of images
		image_files = []
		pdf_files = []
		# Iterate through all the pages stored above
		image_counter = 1
		for page in pages:
			# config["image_scale"] = page.height / config["height"]
			config["image_scale"] = dpi

			# Declaring filename for each page of PDF as JPG
			# For each page, filename will be:
			# PDF page n -> page_n.jpg

			file_prefix = pdf_file + "_page_" + str(image_counter)
			filename = file_prefix + ".jpg"

			# Save the image of the page in system
			page.save(filename, 'JPEG')

			image_files.append(filename)
			image_counter = image_counter + 1

			pre_processors = self.get_processors_before_ocr()
			img = cv2.imread(filename)
			filename = self.preprocess_image(filename, img, pre_processors, config)

			# Part #2 - Recognizing text from the images using OCR
			logging.info("Before sending images of file {} for OCR using tesseract, Page {} ".format(filename, image_counter))

			# img = self.preprocess_file(file_name, output_config)
			pdf_output = pytesseract.image_to_pdf_or_hocr(filename,extension="pdf")
			page_pdf = file_prefix + "_ocred.pdf"
			f = open(page_pdf, "wb")
			f.write(pdf_output)
			f.close()
			pdf_files.append(page_pdf)

		# merge pdf files
		f = open(config["file_name"], "wb")
		self.pdf_cat(pdf_files, f)
		f.close()
		logging.info("Successfully generated OCRed PDF of file {} using tesseract ".format(filename))

		return config["file_name"]


	def ocr(self, file_name, output_config):
		"""
		"""
		try:
			logging.info("About to preprocess file {} before tesseract OCR ".format(file_name))
			img = self.preprocess_file(file_name, output_config)

			tess_config = self.get_tess_config(output_config)
			logging.info("Successfully preprocessed file {}. Submitting for tesseract OCR data".format(file_name))
			ocr_data = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT)
			#, config = tess_config)

			logging.info(
				"Successfully got OCR data for file {} using tesseract version {}. About to get OSD".format(file_name,
																											pytesseract.get_tesseract_version()))
			angle = 0
			try:
				newdata = pytesseract.image_to_osd(img)
				# , config=tess_config)
				angle = int(re.search('(?<=Rotate: )\d+', newdata).group(0))
			except Exception as e:
				logging.error("Error while doing image_to_osd for file {}".format(file_name), exc_info=True)

			logging.info(
				"Successfully got OSD file {} using tesseract. Angle is {}. About to process the result".format(
					file_name, str(angle)))
			ocr_result = self._process_result(ocr_data, angle, output_config)
			logging.info("Successfully completed OCR for file {} using tesseract".format(file_name))

			return ocr_result
		except Exception as e:
			logging.error("Error while processing {} for OCR using tesseract".format(file_name), exc_info=True)
			raise SystemError("Unexpected error while doing OCR for file {} using Tesseract".format(file_name))

	def pdf_cat(self, input_files, output_stream):
		input_streams = []
		try:
			# First open all the files, then produce the output file, and
			# finally close the input files. This is necessary because
			# the data isn't read from the input files until the write
			# operation. Thanks to
			# https://stackoverflow.com/questions/6773631/problem-with-closing-python-pypdf-writing-getting-a-valueerror-i-o-operation/6773733#6773733
			for input_file in input_files:
				input_streams.append(open(input_file, 'rb'))
			writer = PdfFileWriter()
			for reader in map(PdfFileReader, input_streams):
				for n in range(reader.getNumPages()):
					writer.addPage(reader.getPage(n))
			writer.write(output_stream)
		finally:
			for f in input_streams:
				f.close()


	def _agg_page_value(ocr_data, page_num, page_prop, agg_op, block_num = None, line_num = None):
		src_array = []
		for i in range(len(ocr_data.get("page_num"))):
			if ocr_data.get("page_num")[i] == page_num:
				if block_num is not None and ocr_data.get("block_num")[i] == block_num:
					if line_num is not None and ocr_data.get("line_num")[i] == line_num:
						src_array.append(ocr_data.get(page_prop)[i])
					elif line_num is None:
						src_array.append(ocr_data.get(page_prop)[i])
				elif block_num is None:
					src_array.append(ocr_data.get(page_prop)[i])

		if agg_op == "max":
			return max(src_array)
		elif agg_op == "min":
			return min(src_array)
		else:
			raise ValueError("Invalid {} operation passed".format(agg_op))

	def _get_set_page_object(self, ocr_data, pages, page_num, angle):
		for p in pages:
			if p.get("page") == page_num:
				return p
		page = {
			"page": page_num,
			"unit": "PIXEL",
			"width": ocr_data["width"][0],
			"height": ocr_data["height"][0],
			"orig_clockwise_orientation": angle * -1,
			"clockwise_orientation": angle * -1,
			"additional_properties": "",
			"blocks": []
		}
		pages.append(page)
		return page


	def _get_set_block_object(self, blocks, block_num):
		for b in blocks:
			if b.get("block") == block_num:
				return b
		block = {
			"block": block_num,
			"lines": []
		}
		blocks.append(block)
		return block

	def _get_set_line_object(self, lines, line_num):
		for l in lines:
			if l.get("line") == line_num:
				return l
		line = {
			"line": line_num,
			"text": "",
			"bounding_box": None,
			"words": []
		}
		lines.append(line)
		return line

	def _process_result(self, ocr_data, angle, output_config):
		pages = [];
		for i in range(len(ocr_data.get("text"))):
			text = ocr_data.get("text")[i]
			if text.strip() == "":
				continue
			page = self._get_set_page_object(ocr_data, pages, ocr_data.get("page_num")[i], angle)
			block = self._get_set_block_object(page.get("blocks"), ocr_data.get("block_num")[i])
			line = self._get_set_line_object(block.get("lines"), ocr_data.get("line_num")[i])

			left = ocr_data.get("left")[i]
			top = ocr_data.get("top")[i]
			width = ocr_data.get("width")[i]
			height = ocr_data.get("height")[i]

			text = text.encode("latin-1", "replace").decode("latin-1")
			word = {
				"text": text,
				"bounding_box": self._create_bounding_box(left, top, width,  height)
			}
			line.get("words").append(word)
			line["text"] = line["text"] + " " + text
			if line.get("bounding_box") is None:
				line["bounding_box"] = word.get("bounding_box")
			else:
				line["bounding_box"] = self._get_bounding_box(line.get("bounding_box"), word.get("bounding_box"))

		if output_config.get("change_origin") is not None:
			for page in pages:
				page_width = page.get("width")
				page_height = page.get("height")
				for block in page.get("blocks"):
					for line in block.get("lines"):
						line["bounding_box"] = geometric_util.transform_origin(output_config.get("change_origin"),
																			   line["bounding_box"], page_width, page_height)
						for word in line.get("words"):
							word["bounding_box"] = geometric_util.transform_origin(output_config.get("change_origin"),
																			   word["bounding_box"], page_width, page_height)

		return pages

	def _create_bounding_box(self, left, top, width, height):
		box = []
		box.append(left)
		box.append(top)
		box.append(left + width)
		box.append(top)
		box.append(left + width)
		box.append(top + height)
		box.append(left)
		box.append(top + height)
		return box

	def _get_bounding_box(self, current_box, box_to_include):
		left = min(current_box[0], box_to_include[0])
		top = min(current_box[1], box_to_include[1])
		right = max(current_box[2], box_to_include[2])
		bottom = max(current_box[5], box_to_include[5])
		width = right - left
		height = bottom - top

		return self._create_bounding_box(left, top, width, height)

	def preprocess_image(self, filename, img, pre_processors, output_config):
		if pre_processors is not None and len(pre_processors) > 0:
			context = {
				ImgProcessor.KEY_ORIG_IMAGE: img,
				ImgProcessor.KEY_ORIG_FNAME: filename,
				"config": output_config
			}
			for processor in pre_processors:
				img_processor_factory.get_img_processor(processor).process(context)

			# return the most relevant processed file in the order of preference -> dewarped, oriented, deskewed, original
			# TODO need to come up with a better option for this
			if context.get(ImgProcessor.KEY_DEWARPED_FNAME) is not None:
				return context.get(ImgProcessor.KEY_DEWARPED_FNAME)
			elif context.get(ImgProcessor.KEY_ORIENTED_FNAME) is not None:
				return context.get(ImgProcessor.KEY_ORIENTED_FNAME)
			elif context.get(ImgProcessor.KEY_DESKEWED_FNAME) is not None:
				return context.get(ImgProcessor.KEY_DESKEWED_FNAME)
			else:
				return context.get(ImgProcessor.KEY_ORIG_FNAME)
		else:
			return filename


OcrProvider.register(TesseractOcrProvider)


if __name__ == "__main__":
	# Get an image with printed text
	# remote_image_printed_text_url = "https://storage.googleapis.com/arunramkrish/ACDPL_Mini.png"
	# remote_image_printed_text_url = "https://storage.googleapis.com/arunramkrish/Classic-Collection-Yes-Bank-p1.png"
	# remote_image_printed_text_url = "https://storage.googleapis.com/arunramkrish/Classic-Collection-Yes-Bank-p2.png"
	# remote_image_printed_text_url = "https://storage.googleapis.com/arunramkrish/Classic-Collection-Yes-Bank-p3.png"
	# load the example image and convert it to grayscale
	# image = open("images/input/ACDPL_Mini.png", "rb")
	# ap = argparse.ArgumentParser()
	# ap.add_argument("-i", "--image", required=True,
	# 				help="path to input image to be OCR'd")
	# ap.add_argument("-p1", "--preprocess1", type=str, default="none",
	# 				help="removing noise by median blurring")
	# ap.add_argument("-p2", "--preprocess2", type=str, default="none",
	# 				help="type of preprocessing to be done")
	# args = vars(ap.parse_args())
	ex_config = {
		"preprocess1": "blur",
		"preprocess2": "thresh"
	}
	input_file = "F:/RamLabs/Consulting/Finstinct/src/finstinct-ocr-service/images/input/tess_BOI-Kannan.pdf"
	result = TesseractOcrProvider().ocr_to_pdf(input_file, ex_config)
	output_file = "F:/RamLabs/Consulting/Finstinct/src/finstinct-ocr-service/images/input/tess_BOI-Kannan_ocred.pdf"
	f = open(output_file, "wb")
	f.write(result)
	f.close()
	print("Completed writing")
	# show the output images
	# cv2.imshow("Image", image)
	# cv2.imshow("Output", gray)
	# cv2.waitKey(0)