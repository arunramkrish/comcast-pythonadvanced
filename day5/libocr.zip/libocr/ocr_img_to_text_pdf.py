import os
import logging

from libocr.factory import ocr_provider_factory
from libocr.factory import output_formatter_factory
from libimageproc import img_processor_factory
from libimageproc.img_processor import ImgProcessor
from libimageproc.img_io import ImageFile
from libimageproc.rotation import img_rotation


def get_ocr_provider_from_file_name(file_name, available_providers, sep=os.sep):
    head, tail = os.path.split(file_name)
    try:
        first_key_word_end_index = tail.index("_")
    except ValueError as e:
        return None
    if first_key_word_end_index != -1:
        first_key_word = tail[0:first_key_word_end_index]
        try:
            key_index = available_providers.index(first_key_word)
            return first_key_word
        except ValueError as e:
            return None


def get_ocr_service(pdf_file, config):
    svc_name = config.get("ocr_svc")
    if svc_name is None:
        svc_name = get_ocr_provider_from_file_name(pdf_file, ocr_provider_factory.avaiable_providers())

        if svc_name is None:
            svc_name = ocr_provider_factory.get_default_provider()
    return svc_name


def ocr_images(images, output_config):
    if len(images) <= 0:
        return

    # Variable to get count of total number of pages
    file_limit = len(images)
    output_config["total_pages"] = file_limit

    svc_name = get_ocr_service(images[0], output_config)
    ocr_service = ocr_provider_factory.get_ocr_provider(svc_name)
    # obtain preprocessors based on ocr service
    pre_processors = ocr_service.get_processors_before_ocr()

    # obtain output formatters based on ocr service
    output_formatters = []
    out_fmts = output_config.get("out_fmt")
    supported_output_formats = ocr_service.get_supported_output_formats()
    if not isinstance(out_fmts, list):
        temp = []
        temp.append(out_fmts)
        out_fmts = temp
    for out_fmt in out_fmts:
        if out_fmt in supported_output_formats:
            output_formatters.append(output_formatter_factory.get_output_formatter(out_fmt))

    try:
        # Iterate from 1 to total number of pages
        for i in range(0, file_limit):
            output_config["current_page"] = i
            if (output_config.get("process_pages") is not None) and (i not in output_config.get("process_pages")):
                # keep the output formatter aware that the current page is skipped
                for output_formatter in output_formatters:
                    output_formatter.output_ocr_result(None, output_config)
                continue

            filename = images[i]
            img = ImageFile.read_image(filename)

            # Recognize the text as string in image
            # ocr_response = pytesseract.image_to_string(Image.open(filename))
            logging.info("About to do ocr for the file {} using ocr service from {}".format(filename, svc_name))

            # preprocess based on ocr service
            filename = preprocess(filename, img, pre_processors, output_config)

            ocr_response = ocr_service.ocr(filename, output_config)
            logging.info("Successfully completed ocr for the file {} using ocr service from {}".format(filename, svc_name))

            if len(ocr_response) > 0:
                page = ocr_response[0]
                # check orientation from ocr. If its giving rotation, again rotate image and do OCR
                angle = page.get("orig_clockwise_orientation")
                if angle != 0 and is_angle_within_threshold(angle, output_config.get("ocr_angle_rotate_threshold")):
                    rotated = img_rotation.rotate(img, angle)
                    filename = images[i] + "_oriented.jpg"
                    ImageFile.imwrite(filename, rotated)
                    ocr_response = ocr_service.ocr(filename, output_config)
                    logging.info(
                        "Successfully completed ocr after re-rotation for the file {} using ocr service from {}".format(filename, svc_name))
                    page = ocr_response[0]
                    # check orientation from ocr. If its giving rotation, again rotate image and do OCR
                    angle = page.get("orig_clockwise_orientation")
                    if angle != 0 and is_angle_within_threshold(angle, output_config.get("ocr_angle_rotate_threshold")):
                        logging.error("Even after doing OCR twice, orientation is still not zero, but {}".format(str(angle)))

                # call each of the output format that is requested provided the chosen ocr service supports it
                for output_formatter in output_formatters:
                    logging.info(
                        "About to format ocr results of the file {} using ocr formatter {}".format(filename, out_fmt))
                    output_formatter.output_ocr_result(ocr_response, output_config)
                    logging.info(
                        "Successfully formatted ocr results of the file {} using ocr formatter {}".format(filename,
                                                                                                      out_fmt))
            else:
                logging.error("No OCR output of the file {} ".format(filename))
        # end for iterating individual pages
    except Exception as e:
        logging.error("Unexpected exception occurred while doing OCR for file {}".format(images[0]), exc_info=True)
        # TODO Raise OCR Exception
        raise SystemError("Unexpected exception occurred while doing OCR for file {}".format(images[0]))


def preprocess(filename, img, pre_processors, output_config):
    if pre_processors is not None and len(pre_processors) > 0:
        context = {
            ImgProcessor.KEY_ORIG_IMAGE: img,
            ImgProcessor.KEY_ORIG_FNAME: filename,
            "config": output_config
        }
        for processor in pre_processors:
            img_processor_factory.get_img_processor(processor).process(context)

        #return the most relevant processed file in the order of preference -> dewarped, oriented, deskewed, original
        #TODO need to come up with a better option for this
        if context.get(ImgProcessor.KEY_DEWARPED_FNAME) is not None:
            return context.get(ImgProcessor.KEY_DEWARPED_FNAME)
        elif context.get(ImgProcessor.KEY_ORIENTED_FNAME) is not None:
            return context.get(ImgProcessor.KEY_ORIENTED_FNAME)
        elif context.get(ImgProcessor.KEY_DESKEWED_FNAME) is not None:
            return context.get(ImgProcessor.KEY_DESKEWED_FNAME)
        else:
            return context.get(ImgProcessor.KEY_ORIG_FNAME)
    else:
        return filename
    # if output_config.get("dewarp") is True:
    #     #deskew smaller angles to bring it either horizontal or vertical
    #     img = deskew.deskew_image(img, filename)
    #
    #     # rotate as required before dewarping
    #     img = img_rotation.get_processor(img_rotation.TESS).process_image(img, filename)
    #
    #     #do dewarp
    #     #TODO As more middleware come into play chain them rather than inlining inside method
    #     dewarped_files = []
    #     dewarp_status = page_dewarp.dewarp_image(img, filename, dewarped_files, output_config)
    #     if dewarp_status is True and len(dewarped_files) > 0:
    #         filename = dewarped_files[0]


def is_angle_within_threshold(angle, threshold = 15.0):
    if threshold is None:
        threshold = 15.0
    return (angle <= threshold) and (angle >= (threshold * -1))


if __name__ == "__main__":
    # "https://storage.googleapis.com/arunramkrish/Classic-Collection-Yes-Bank.pdf"
    ex_images = [
        "https://storage.googleapis.com/arunramkrish/Classic-Collection-Yes-Bank-p1.png",
        "https://storage.googleapis.com/arunramkrish/Classic-Collection-Yes-Bank-p2.png",
        "https://storage.googleapis.com/arunramkrish/Classic-Collection-Yes-Bank-p3.png"
    ]
    # Creating a text file to write the output
    ex_output_config = {"file_name": "output.pdf", "width": 210, "height": 297}
    ocr_images(ex_images, ex_output_config)