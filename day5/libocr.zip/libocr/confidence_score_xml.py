import xml.etree.ElementTree as ET
import logging
import os
import sys
from functools import lru_cache

def fetch_word_char_variants(xml_filename: str, page_no: int, og_bbox: dict, text: str, do_transform=True):
    """

    :param xml_filename: Path to xml file
    :param page_no: 0 based index of page
    :param og_bbox: Bounding box within which text has to be looking. original coordinates is expected
    :param text:
    :return:
    """
    if not os.path.exists(xml_filename):
        raise FileNotFoundError

    # logging.info("About to extract word, char variants from file: {}, page: {}, bbox: [{},{},{},{}], text: {}".
    #               format(xml_filename, page_no, og_bbox[0], og_bbox[1], og_bbox[2], og_bbox[3], text))

    root = parse_xml(xml_filename)
    ns_attrib =  [s for s in root.attrib.keys() if "schemaLocation" in s][0]
    ns = root.attrib.get(ns_attrib).split()[0]
    namespaces = {'': ns}
    page_element = root.findall("./page", namespaces)[page_no]

    # origins and scale has to be changed to the coordinate system in xml
    trans_bbox = transform_bbox(og_bbox, page_element) if do_transform else og_bbox
    # logging.debug("After transformation bbox to check is: [{},{},{},{}]".format(trans_bbox[0], trans_bbox[1],
    #                                                                            trans_bbox[2], trans_bbox[3]))

    # line inside block has the bounding box attributes. Find out those lines that contain the given bounding box
    line_elements = get_matching_line_elements(page_element, trans_bbox, namespaces)
    if len(line_elements) == 0:
        # logging.info("No matching line for the box [{},{},{},{}] with text{}".format(trans_bbox[0], trans_bbox[1],
        #                                                                              trans_bbox[2], trans_bbox[3], text))
        return None, None

    # line has one or more formatting elements where group of chars with same formats are grouped for every word (
    # delimited by spaces), there are word variant elements preceding charparams elemnt corresponding to characters
    # in the word. get variant that contains given text from the variants and also ensure chars are inside bbox
    matching_word_variants, matching_char_variants = get_matching_variant_elements(line_elements, namespaces, text,
                                                                                   trans_bbox)
    if len(matching_word_variants) == 0:
        # logging.info("No matching variants containing the given text {}".format(text))
        return None, None

    word_variants = get_word_variants(matching_word_variants, namespaces)
    char_variants = get_char_variants(matching_char_variants, namespaces)
    return word_variants, char_variants


@lru_cache(maxsize=1)
def parse_xml(xml_filename: str):
    #TODO move to XMLPullParser to handle large XML files
    #Refer https://docs.python.org/3/library/xml.etree.elementtree.html
    tree = ET.parse(xml_filename)
    return tree.getroot()


def transform_bbox(og_bbox, page_element):
    # og_bbox is in the order left, bottom, right, top with origin in left bottom
    # transform to left, top, right, bottom with origin in left top

    resolution = int(page_element.attrib.get("resolution"))
    width = int(page_element.attrib.get("width"))
    height = int(page_element.attrib.get("height"))
    input_resolution = 72

    left = og_bbox[0] * resolution / input_resolution
    top = height - (og_bbox[3] * resolution / input_resolution)
    right = og_bbox[2] * resolution / input_resolution
    bottom = height - (og_bbox[1] * resolution / input_resolution)

    return [left, top, right, bottom]


def get_matching_variant_elements(line_elements, namespaces, text, og_bbox):
    words_list = text.split()
    word_index = 0

    all_word_variants = []
    all_char_variants = []

    for line in line_elements:
        # line has one or more formatting elements
        formatting_elements = line.findall(".//formatting", namespaces)
        for fe in formatting_elements:
            # formatting element has word variants followed by sequence of char params present in word and again
            # repeats word variants-char params sequence until the same format is preserved
            inside_relevant_variants = False

            for child_of_fe in fe:
                # check for the given text in word variant and ensure all char sequence IMMEDIATELY succeeding them to
                # be inside the given bbox. Both these conditions to satisfy. Else check with other variants
                if child_of_fe.tag.endswith("wordRecVariants"):
                    # if we have already got the relevant variants from the previous set just break out
                    if inside_relevant_variants:
                        if word_index == len(words_list):
                            # we have matched all words in the given text
                            break
                        else:
                            # we got to match the rest of the words. reset state to match the next word
                            inside_relevant_variants = False

                    variant_elements = child_of_fe.findall(".//variantText", namespaces)
                    matching_ve = None
                    for ve in variant_elements:
                        if words_list[word_index] in ve.text:
                            # found the current word
                            matching_ve = ve
                            # job not done yet until all words are matched
                            word_index = word_index + 1
                            break
                    if matching_ve is not None:
                        # There is a variant with the given text
                        # logging.debug("Found matching variant {}".format(ve.text))
                        inside_relevant_variants = True
                        matching_word_variants = child_of_fe.findall("./wordRecVariant", namespaces)
                        all_word_variants.append(matching_word_variants)
                    else:
                        # there is no variant matching given text, clear the partial match if it was there earlier
                        all_word_variants = []
                        all_char_variants = []
                        # start matching from beginning
                        word_index = 0

                elif child_of_fe.tag.endswith("charParams") and inside_relevant_variants:
                    # only if the char in char params is present in given text, it is relevant

                    #TODO char check is not working. it is fetching newline
                    # if child_of_fe.text not in text:
                    #     continue

                    # now check if all chars alongside are inside og_bbox
                    # if check_charparams_element_box(child_of_fe, og_bbox, text, namespaces):
                    all_char_variants.append(child_of_fe)
                    # matching_char_variants.append(child_of_fe)
                    # else:
                        # char is outside the box, so we are not in relevant variants,
                        # reset and check with next section of variants
                        # inside_relevant_variants = False
                        # matching_word_variants.clear()
                        # matching_char_variants.clear()
                        # logging.info("No matching charparams element with char {}".format(child_of_fe.text))

            if word_index == len(words_list):
                break
            # if len(matching_word_variants) > 0 and len(matching_char_variants) > 0:
            #     break

        if word_index == len(words_list):
            break

        # if len(matching_word_variants) > 0 and len(matching_char_variants) > 0:
        #     break
    return all_word_variants, all_char_variants


def check_charparams_element_box(char_params_element, og_bbox, text, namespaces):
    char_params_box = get_element_bbox(char_params_element)
    return check_bbox_inside(og_bbox, char_params_box)


def get_word_variants(all_word_variant_elements, namespaces):
    """
    Extract only word and confidence score from the variant element

    @param all_word_variant_elements:
    @param namespaces:
    @return:cartesian product of variants in each word
    """
    # each element contains variants for the word in that index
    all_word_variants = []
    for word_variant_elements in all_word_variant_elements:
        word_variants = []
        for ele in word_variant_elements:
            variant_element = ele.findall("./variantText", namespaces)[0]
            word_variants.append(get_single_word_variant(variant_element, namespaces))
        all_word_variants.append(word_variants)

    return merge_all_word_variants(all_word_variants)


def merge_all_word_variants(all_word_variants):
    """
    Recursively create cartesian product of individual word variants to construct all combinations of the variants
    for the given sequence of words
    @param all_word_variants: containing variants for each word in the list
    @return: combined variants of all words
    """
    if len(all_word_variants) <= 1:
        return all_word_variants[0]

    current_word_variants = all_word_variants.pop(0)
    # recurse to compute the various of remaining words
    next_words_variants = merge_all_word_variants(all_word_variants)

    merged_variants = []
    for current_variant in current_word_variants:
        for next_variant in next_words_variants:
            all_confidence_scores = [current_variant["confidence_score"]]
            if next_variant.get("all_confidence_scores") is None:
                all_confidence_scores.append(next_variant["confidence_score"])
            else:
                all_confidence_scores.extend(next_variant.get("all_confidence_scores"))
            merged_variant = {
                "word": current_variant["word"] + " " + next_variant["word"],
                "all_confidence_scores": all_confidence_scores,
                "confidence_score": sum(all_confidence_scores) / len(all_confidence_scores)
            }
            merged_variants.append(merged_variant)
    return merged_variants


def get_single_word_variant(variant_element, namespaces):
    variant = {}
    word = variant_element.text

    # compute char confidences
    char_confidences = []
    for char_index in range(0, len(word)):
        elements = variant_element.findall("./charParams", namespaces)
        if elements is not None and len(elements) > char_index:
            char_params_element = elements[char_index]
            selected_char = char_params_element.text
            char_variants = char_params_element.findall(".//charRecVariant", namespaces)
            if len(char_variants) <= 0:
                continue
            matching_variant = char_variants[0]
            for char_variant in char_variants:
                if char_variant.text == selected_char:
                    matching_variant = char_variant
                    break
            char_confidences.append(int(matching_variant.attrib.get("charConfidence")))

    # average of char confidences as confidence score of word
    variant["word"] = word
    variant["confidence_score"] = sum(char_confidences) / len(word)
    return variant


def get_char_variants(char_variants_elements, namespaces):
    """
    Finds variant for each char from the given list of charParams eleement where each in the list contain char variants
    :param char_variants_elements: list of char params element
    :param namespaces: parent namespace dict to search
    :return: array of arrays for each char in the line_element text. For each index lists char variants
    """
    char_variants = []
    for variants_element in char_variants_elements:
        char_variant_elements = variants_element.findall(".//charRecVariant", namespaces)
        char_options = []
        for ele in char_variant_elements:
            char_variant = {
                "char": ele.text,
                "confidence_score": int(ele.attrib.get("charConfidence"))
            }
            char_options.append(char_variant)
        if len(char_options) > 0:
            char_variants.append(char_options)

    return char_variants


def get_matching_line_elements(page_element, og_bbox, namespaces):
    """
    Page has blocks. Block has lines. Check for the containing block and then check for the containing line within the block
    :param page_element:
    :param og_bbox:
    :param namespaces:
    :return:
    """
    all_blocks = page_element.findall("./block", namespaces)
    lines_matching_boundaries = []
    parent_block = None
    for block in all_blocks:
        bbox = get_element_bbox(block)
        box_inside = check_bbox_inside(bbox, og_bbox)
        if box_inside:
            parent_block = block
            break
    if parent_block is None:
        # logging.info("No matching block for the box [{},{},{},{}]".format(og_bbox[0], og_bbox[1], og_bbox[2], og_bbox[3]))
        return lines_matching_boundaries

    # Find out lines inside the block that encloses the bbox. There is a slight chance that there can be multiple
    # such contending lines. So keep them all until we match the given text
    lines_in_block = parent_block.findall(".//line", namespaces)

    for line in lines_in_block:
        bbox = get_element_bbox(line)
        box_inside = check_bbox_inside(bbox, og_bbox)
        # logging.info("While matching line, Box inside or not {}".format(box_inside))
        if box_inside:
            lines_matching_boundaries.append(line)
            # logging.debug("Found enclosing Line with bbox {}".format(bbox))

    # TODO currently the coordinates are matching with neighbouring lines and not with correct enclosing lines
    # return lines_matching_boundaries
    return lines_in_block


def get_element_bbox(element):
    """
    Create bounding box from l,t,r,b attributes of the element
    :param element:
    :return:
    """
    return [get_attr_value_as_int(element, "l"), get_attr_value_as_int(element, "t"),
            get_attr_value_as_int(element, "r"), get_attr_value_as_int(element, "b")]


def get_attr_value_as_int(element, attr_name):
    if element is None:
        return 0
    if element.attrib.get(attr_name) is None:
        return 0
    try:
        return int(element.attrib.get(attr_name))
    except Exception as e:
        return 0

def check_bbox_inside(parent_bbox, bbox_to_check):
    """
    Check rectangle containment with origin in left, top corner
    :param parent_bbox:
    :param bbox_to_check:
    :return:true if bbox_to_check is inside parent_bbox
    """
    l, t, r, b = 0, 1, 2, 3
    mid_x = (bbox_to_check[l] + bbox_to_check[r]) / 2
    mid_y = (bbox_to_check[t] + bbox_to_check[b]) / 2

    return parent_bbox[l] <= mid_x <= parent_bbox[r] and parent_bbox[t] <= mid_y <= parent_bbox[b]


if __name__ == "__main__":
    logging.basicConfig(format='%(asctime)s:%(levelname)s:%(message)s', stream=sys.stdout, level=logging.DEBUG)
    xml_filename = "BG MEMBER LETTER-3_ocred.xml"
    page_no = 0
    og_bbox = [395.599999809, 942.839361924, 481.75447380900005, 954.684096644]
    text = "Date"
    wv, cv = fetch_word_char_variants(xml_filename, page_no, og_bbox, text)
    logging.info("Word variants {}".format(wv))
    logging.info("Char variants {}".format(cv))

    assert wv is not None
    assert cv is not None
