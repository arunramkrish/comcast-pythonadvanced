from google.cloud import vision

# image_uri = 'gs://cloud-vision-codelab/otter_crossing.jpg'
# image_uri = 'https://storage.googleapis.com/arunramkrish/DECEMBER-19-2019001-1.png'

# image_uri = "gs://arunramkrish/DECEMBER-19-2019001-1.png"
# image_uri = "gs://arunramkrish/FCL_DISCL_FCIPL_p1.png"
# image_uri = "gs://arunramkrish/FCL_DISCL_FCIPL_p2.png"
# image_uri = "gs://arunramkrish/DB_31_ocred-p3.png"
# image_uri = "gs://arunramkrish/ACDPL_Mini.png"
#image_uri = "gs://arunramkrish/Classic-Collection-Yes-Bank-p3.png"
#image_uri = "gs://arunramkrish/Fashionista-Canara-Bank_p13.png"
# image_uri = "gs://arunramkrish/HDFC-Banks-st.png"
image_uri = "gs://arunramkrish/R G Udyog Balance Sheet FY 2010_p24.png"

client = vision.ImageAnnotatorClient()
image = vision.types.Image()
image.source.image_uri = image_uri

response = client.text_detection(image=image)

for text in response.text_annotations:
    print('=' * 79)
    print(f'"{text.description}"')
    vertices = [f'({v.x},{v.y})' for v in text.bounding_poly.vertices]
    print(f'bounds: {",".join(vertices)}')