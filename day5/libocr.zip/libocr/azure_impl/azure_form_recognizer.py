import os
import json
import time
from requests import get, post

import azure.ai.formrecognizer
from azure.core.credentials import AzureKeyCredential
from azure.core.exceptions import ResourceNotFoundError


subscription_id = "f6369d35-ee51-4a73-a88b-4ab50efda4a6"
subscription_key = "1a282075dbf94f29b94c30e2399bbc0f"
subscription_endpoint = "https://finstinct-recognizer.cognitiveservices.azure.com/"

def format_bounding_box(bounding_box):
    if not bounding_box:
        return "N/A"
    return ", ".join(["[{}, {}]".format(p.x, p.y) for p in bounding_box])

class RecognizeContentSample(object):

    def recognize_content(self, input_file_name):
        # path_to_sample_forms = os.path.abspath(os.path.join(os.path.abspath(__file__), "..", "./sample_forms/forms/Invoice_1.pdf"))
        path_to_sample_forms = os.path.abspath(input_file_name)

        # [START recognize_content]
        from azure.core.credentials import AzureKeyCredential
        from azure.ai.formrecognizer import FormRecognizerClient

        # endpoint = os.environ["AZURE_FORM_RECOGNIZER_ENDPOINT"]
        # key = os.environ["AZURE_FORM_RECOGNIZER_KEY"]
        endpoint = subscription_endpoint
        key = subscription_key

        form_recognizer_client = FormRecognizerClient(endpoint=endpoint, credential=AzureKeyCredential(key))
        with open(path_to_sample_forms, "rb") as f:
            poller = form_recognizer_client.begin_recognize_content(form=f)
        contents = poller.result()

        for idx, content in enumerate(contents):
            print("----Recognizing content from page #{}----".format(idx))
            print("Has width: {} and height: {}, measured with unit: {}".format(
                content.width,
                content.height,
                content.unit
            ))
            for table_idx, table in enumerate(content.tables):
                print("Table # {} has {} rows and {} columns".format(table_idx, table.row_count, table.column_count))
                for cell in table.cells:
                    print("...Cell[{}][{}] has text '{}' within bounding box '{}'".format(
                        cell.row_index,
                        cell.column_index,
                        cell.text,
                        format_bounding_box(cell.bounding_box)
                    ))
                    # [END recognize_content]
            for line_idx, line in enumerate(content.lines):
                print("Line # {} has word count '{}' and text '{}' within bounding box '{}'".format(
                    line_idx,
                    len(line.words),
                    line.text,
                    format_bounding_box(line.bounding_box)
                ))
                for word in line.words:
                    print("...Word '{}' has a confidence of {}".format(word.text, word.confidence))
            print("----------------------------------------")


    def train_model(self):
        ########### Python Form Recognizer Labeled Async Train #############

        # Endpoint URL
        endpoint = "https://finstinct-recognizer.cognitiveservices.azure.com/"
        post_url = endpoint + r"formrecognizer/v2.0-preview/custom/models"
        source = r"https://finstinctstore.blob.core.windows.net/samplefiles?sv=2019-10-10&ss=bfqt&srt=sco&sp=rwdlacupx&se=2020-06-30T00:53:27Z&st=2020-06-22T16:53:27Z&spr=https&sig=DCDU1kerDZjbiy8O%2FRnZOT2IoNW%2F0emppCw5b6lIja0%3D"
        # Blobfolder name
        prefix = "azuresamples"
        includeSubFolders = False
        useLabelFile = False

        headers = {
            # Request headers
            'Content-Type': 'application/json',
            'Ocp-Apim-Subscription-Key': subscription_key,
        }

        body = {
            "source": source,
            "sourceFilter": {
                "prefix": prefix,
                "includeSubFolders": includeSubFolders
            },
            "useLabelFile": useLabelFile
        }

        try:
            resp = post(url=post_url, json=body, headers=headers)
            if resp.status_code != 201:
                print("POST model failed (%s):\n%s" % (resp.status_code, json.dumps(resp.json())))
                quit()
            print("POST model succeeded:\n%s" % resp.headers)
            get_url = resp.headers["location"]
            return get_url
        except Exception as e:
            print("POST model failed:\n%s" % str(e))
            quit()


    def fetch_training_response(self, get_url):
        headers = {
            # Request headers
            'Content-Type': 'application/json',
            'Ocp-Apim-Subscription-Key': subscription_key,
        }
        n_tries = 15
        n_try = 0
        wait_sec = 5
        max_wait_sec = 60
        while n_try < n_tries:
            try:
                resp = get(url=get_url, headers=headers)
                resp_json = resp.json()
                if resp.status_code != 200:
                    print("GET model failed (%s):\n%s" % (resp.status_code, json.dumps(resp_json)))
                    quit()
                model_status = resp_json["modelInfo"]["status"]
                if model_status == "ready":
                    print("Training succeeded:\n%s" % json.dumps(resp_json))
                    return resp_json
                if model_status == "invalid":
                    print("Training failed. Model is invalid:\n%s" % json.dumps(resp_json))
                    quit()
                # Training still running. Wait and retry.
                time.sleep(wait_sec)
                n_try += 1
                wait_sec = min(2 * wait_sec, max_wait_sec)
            except Exception as e:
                msg = "GET model failed:\n%s" % str(e)
                print(msg)
                quit()
        print("Train operation did not complete within the allocated time.")


    def get_model(self, model_id, file_path):
        ########### Python Form Recognizer Async Analyze #############

        # Endpoint URL
        endpoint = subscription_endpoint
        apim_key = subscription_key
        post_url = endpoint + "/formrecognizer/v2.0-preview/custom/models/%s/analyze" % model_id
        source = file_path
        params = {
            "includeTextDetails": True
        }

        headers = {
            # Request headers
            'Content-Type': 'application/pdf',
            'Ocp-Apim-Subscription-Key': apim_key,
        }
        with open(source, "rb") as f:
            data_bytes = f.read()

        try:
            resp = post(url=post_url, data=data_bytes, headers=headers, params=params)
            if resp.status_code != 202:
                print("POST analyze failed:\n%s" % json.dumps(resp.json()))
                quit()
            print("POST analyze succeeded:\n%s" % resp.headers)
            get_url = resp.headers["operation-location"]
            return get_url
        except Exception as e:
            print("POST analyze failed:\n%s" % str(e))
            quit()


    def get_model_result(self, operation_location):
        n_tries = 15
        n_try = 0
        wait_sec = 5
        max_wait_sec = 60
        while n_try < n_tries:
            try:
                resp = get(url=operation_location, headers={"Ocp-Apim-Subscription-Key": subscription_key})
                resp_json = resp.json()
                if resp.status_code != 200:
                    print("GET analyze results failed:\n%s" % json.dumps(resp_json))
                    quit()
                status = resp_json["status"]
                if status == "succeeded":
                    print("Analysis succeeded:\n%s" % json.dumps(resp_json))
                    quit()
                if status == "failed":
                    print("Analysis failed:\n%s" % json.dumps(resp_json))
                    quit()
                # Analysis still running. Wait and retry.
                time.sleep(wait_sec)
                n_try += 1
                wait_sec = min(2 * wait_sec, max_wait_sec)
            except Exception as e:
                msg = "GET analyze results failed:\n%s" % str(e)
                print(msg)
                quit()
        print("Analyze operation did not complete within the allocated time.")

if __name__ == '__main__':
    sample = RecognizeContentSample()
    # input_file = "C:/Users/Arunkumar/Downloads/Rupa - Statement.pdf"
    # sample.recognize_content(input_file)
    get_url = sample.train_model()
    if get_url is not None:
        model_id = sample.fetch_training_response(get_url)

    model_id = "9cfe6008-05ba-4ff4-b834-97533933fc4e"
    file_path = "F:/Learning/ComputerVision/MicrosoftAzureVision/Test/Invoice_6.pdf"
    operation_location = sample.get_model(model_id, file_path)

    operation_location = "https://finstinct-recognizer.cognitiveservices.azure.com/formrecognizer/v2.0-preview/custom/models/9cfe6008-05ba-4ff4-b834-97533933fc4e/analyzeresults/5a91af51-f99a-44ae-a488-9b78a7256dec"
    sample.get_model_result(operation_location)
