from azure.cognitiveservices.vision.computervision import ComputerVisionClient
from azure.cognitiveservices.vision.computervision.models import TextOperationStatusCodes
from msrest.authentication import CognitiveServicesCredentials

from array import array
import os
import time
import logging
from libocr.ocr_provider import OcrProvider
import libocr.util.text_rotation as text_rotation
from libocr.util import geometric_util


class AzureOcrProvider:
    """
    Virtually implements OcrProvider interface using Azure's Computer Vision Library. Takes an image and returns a
    JSON containing texts along with their bounding boxes with coorinates and dimensions with reference to the image
    """

    def __init__(self):
        self.computervision_client = None

    def supports_multipage_pdf(self):
        return False


    def get_supported_output_formats(self):
        return ["dict"]

    def get_processors_before_ocr(self):
        # not using"dewarp"
        return ["deskew", "rotate"]


    def _create_client_from_env(self):
        """
        Creates Computer Vision Client using environment variables COMPUTER_VISION_SUBSCRIPTION_KEY and
        COMPUTER_VISION_ENDPOINT.
        @raise ValueError: In case if these env variables are not set
        @raise SystemError: In case of error while creating ComputerVisionClient
        """
        if 'COMPUTER_VISION_SUBSCRIPTION_KEY' in os.environ:
            subscription_key = os.environ['COMPUTER_VISION_SUBSCRIPTION_KEY']
        else:
            logging.critical(str(os.environ))
            logging.critical(
                "Set the COMPUTER_VISION_SUBSCRIPTION_KEY environment variable.\n**Restart your shell or IDE for "
                "changes to take effect.**")
            raise SystemError("Set the COMPUTER_VISION_SUBSCRIPTION_KEY environment variable.")

        # Add your Computer Vision endpoint to your environment variables.
        if 'COMPUTER_VISION_ENDPOINT' in os.environ:
            endpoint = os.environ['COMPUTER_VISION_ENDPOINT']
        else:
            logging.critical(str(os.environ))
            logging.critical("Set the COMPUTER_VISION_ENDPOINT environment variable.\n**Restart your shell or IDE for "
                             "changes to take effect.**")
            raise SystemError("Set the COMPUTER_VISION_SUBSCRIPTION_KEY environment variable.")

        self.computervision_client = ComputerVisionClient(endpoint, CognitiveServicesCredentials(subscription_key))

    def _create_client_from_config(self, config):
        """
        Creates Computer Vision Client using given config dict containing keys COMPUTER_VISION_SUBSCRIPTION_KEY and
        COMPUTER_VISION_ENDPOINT.
        @raise ValueError: In case if the required keys are not set
        @raise SystemError: In case of error while creating ComputerVisionClient
        """
        subscription_key = config.get('COMPUTER_VISION_SUBSCRIPTION_KEY')
        endpoint = config.get('COMPUTER_VISION_ENDPOINT')

        if subscription_key and endpoint:
            try:
                self.computervision_client = ComputerVisionClient(endpoint,
                                                                  CognitiveServicesCredentials(subscription_key))
            except BaseException as e:
                logging.critical(
                    "Error while creating Computer Vision Client", exc_info=True)
                raise SystemError("Error while creating Computer Vision Client ") from e
        else:
            logging.critical(
                "Need to pass config values for COMPUTER_VISION_SUBSCRIPTION_KEY and COMPUTER_VISION_ENDPOINT")
            raise ValueError(
                "Need to pass config values for COMPUTER_VISION_SUBSCRIPTION_KEY and COMPUTER_VISION_ENDPOINT")

    def ocr(self, file_path, output_config):
        """
        Batch Read File, recognize printed text - remote This will extract printed text in an image, then print
        results, line by line. This API call can also recognize handwriting (not shown).

        @param file_path: Link to the file. If this begins with http, it is assumed that the it is a public URL that
        azure can access and the link is directly passed to azure

        @return: Array of Dict objects where each Dict object represents a page. Even though multiple pages are not
        usual images, formats like TIFF supports multiple pages. Here is the json structure for a page {"page",
        "unit", "width","height","clockwise_orientation","additional_properties","lines":[{"bounding_box","text",
        "words": [{{"bounding_box","text"}]}]}
        """
        if self.computervision_client is None:
            # TODO as it was decided that client will not send it from config, move thsi to environment var
            output_config["COMPUTER_VISION_SUBSCRIPTION_KEY"] = "b0efc57e66a241a9ac4340a3f764bc9d"
            output_config["COMPUTER_VISION_ENDPOINT"] = "https://centralindia.api.cognitive.microsoft.com/"
            self._create_client_from_config(output_config)
        try:
            logging.info("Received image {} to do ocr using azure".format(file_path))
            image_contents = None
            if isinstance(file_path, str) and (not file_path.startswith("http")):
                image_contents = open(file_path, "rb")
                logging.info("Extracted binary contents of image {} to do ocr using azure".format(file_path))

            if image_contents is None:
                # Call API with URL and raw response (allows you to get the operation location)
                recognize_printed_results = self.computervision_client.batch_read_file(file_path, raw=True)
                logging.info("Successfully submitted file {} for OCR using azure".format(file_path))
            else:
                header = {'Content-Type': 'application/octet-stream'}
                recognize_printed_results = self.computervision_client.batch_read_file_in_stream(image_contents,
                                                                                                 custom_headers=header,
                                                                                                 raw=True)
                logging.info("Successfully submitted contents of file {} for OCR using azure".format(file_path))

            # Get the operation location (URL with an ID at the end) from the response
            operation_location_remote = recognize_printed_results.headers["Operation-Location"]
            # Grab the ID from the URL
            operation_id = operation_location_remote.split("/")[-1]

            # Call the "GET" API and wait for it to retrieve the results
            while True:
                get_printed_text_results = self.computervision_client.get_read_operation_result(operation_id)
                if get_printed_text_results.status not in ['NotStarted', 'Running']:
                    break
                time.sleep(1)

            # Print the detected text, line by line
            if get_printed_text_results.status == TextOperationStatusCodes.succeeded:
                logging.info(
                    "Azure has successfully completed OCR of file {}. About to process the results".format(file_path))
                ocr_result = self.__process_result(get_printed_text_results.recognition_results, output_config)
                logging.info("Successfully processed OCR result returned by Azure for file {}".format(file_path))

            return ocr_result
        except Exception as e:
            logging.error("Unexpected exception occurred while doing OCR for file {} using Azure".format(file_path),
                          exc_info=True)
            # TODO Raise OCR Exception
            raise SystemError(
                "Unexpected exception occurred while doing OCR for file {} using Azure".format(file_path)) from e

    def process_line(self, recog_line, page_width, page_height, angle, output_config) -> dict:
        """
        Converts line output of azure to our required  line JSON / Dict
        """
        line = {}
        line["bounding_box"] = text_rotation.rotate_bounding_box(page_width, page_height, recog_line.bounding_box, angle)

        # if deskew is required, perform it
        if output_config.get("deskew_line") is not None:
            line["bounding_box"] = geometric_util.deskew_box(line["bounding_box"], output_config.get("deskew_line"))

        # line["bounding_box"] = recog_line.bounding_box
        if output_config.get("change_origin") is not None:
            line["bounding_box"] = geometric_util.transform_origin(output_config.get("change_origin"),
                                                                   line["bounding_box"], page_width, page_height)
        line["text"] = recog_line.text
        line["words"] = []

        for res_word in recog_line.words:
            word = {}
            word["bounding_box"] = text_rotation.rotate_bounding_box(page_width, page_height, res_word.bounding_box, angle)
            # word["bounding_box"] = res_word.bounding_box
            # if deskew is required, perform it
            if output_config.get("deskew_line") is not None:
                word["bounding_box"] = geometric_util.deskew_box(word["bounding_box"], output_config.get("deskew_line"))

            if output_config.get("change_origin") is not None:
                word["bounding_box"] = geometric_util.transform_origin(output_config.get("change_origin"),
                                                                       word["bounding_box"], page_width, page_height)

            word["text"] = res_word.text
            line["words"].append(word)

        return line

    def __process_result(self, text_recog_results, output_config) -> array:
        """
        Converts OCR output of Azure to that of finstinct-ocr service
        """
        pages = []
        for result in text_recog_results:
            page = {}
            page["page"] = result.page
            page["unit"] = str(result.unit)
            page["orig_width"] = result.width
            page["orig_height"] = result.height
            page["orig_clockwise_orientation"] = result.clockwise_orientation * -1
            page["clockwise_orientation"] = get_adjusted_orientation(result.clockwise_orientation) * -1

            # page["clockwise_orientation"] = 0
            page["additional_properties"] = result.additional_properties

            (page["width"], page["height"]) = text_rotation.rotate_width_height(page["orig_width"], page["orig_height"], page["clockwise_orientation"])

            # azure doesn't provide blocks. so create a place holder block and then add lines to it
            page["blocks"] = []
            block = {
                "block": 0,
                "lines": []
            }
            page["blocks"].append(block)

            line_index = 0
            for line in result.lines:
                line = self.process_line(line, result.width, result.height, page["clockwise_orientation"], output_config)
                line["line"] = line_index
                block["lines"].append(line)
                line_index = line_index + 1

            pages.append(page)

        return pages


def get_adjusted_orientation(given_orientation):
    negative_val = False
    if given_orientation < 0:
        negative_val = True
        given_orientation = given_orientation * -1

    adj_angle = given_orientation
    if (given_orientation <= 45.0) or (given_orientation > 315 and given_orientation <= 360):
        adj_angle = 0
    elif given_orientation > 45.0 and given_orientation <= 135:
        adj_angle = 90
    elif given_orientation > 135.0 and given_orientation <= 225:
        adj_angle = 180
    elif given_orientation > 215.0 and given_orientation <= 315:
        adj_angle = 270
    return adj_angle


OcrProvider.register(AzureOcrProvider)

if __name__ == "__main__":
    # Get an image with printed text
    # remote_image_printed_text_url = "https://storage.googleapis.com/arunramkrish/ACDPL_Mini.png"
    # remote_image_printed_text_url = "https://storage.googleapis.com/arunramkrish/Classic-Collection-Yes-Bank-p1.png"
    # remote_image_printed_text_url = "https://storage.googleapis.com/arunramkrish/Classic-Collection-Yes-Bank-p2.png"
    # remote_image_printed_text_url = "https://storage.googleapis.com/arunramkrish/Classic-Collection-Yes-Bank-p3.png"
    # load the example image and convert it to grayscale
    # image = open("images/input/ACDPL_Mini.png", "rb")
    output_config = {"min_font_size": 4, "dpi": 300, "img_fmt": "jpg", "draw_border": True,
                            "output_word_by_word": True, "out_fmt": ["pdf"], "rotation": True,
                            "ocr_angle_rotate_threshold": 15.0, "DECISION_SLOPE": 2.0, "DECISION_NCLUSTERS": 3,
                            "change_origin": "bottom-left"}
    # remote_image_printed_text_url = "F:/RamLabs/Consulting/Finstinct/Documents/Testing/SampleFiles/Data for Fintech/Data for Fintech/Colocation Undertaking/TM Enrollment/TM ENROLLMENT_SPA1/stamps_64ENROLL_SPA/vendor_notary_1.png"
    remote_image_printed_text_url = "F:/RamLabs/Consulting/Finstinct/Documents/Testing/SampleFiles/Data for Fintech/Data for Fintech/Colocation Undertaking/TM Enrollment/TM ENROLLMENT_SPA1/stamps_64ENROLL_SPA/vendor_notary_1.png"
    result = AzureOcrProvider().ocr(remote_image_printed_text_url, output_config)
    print(str(result))
