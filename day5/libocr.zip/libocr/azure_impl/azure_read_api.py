import sys, os, http.client, urllib.request, urllib.parse, urllib.error, base64

# Add your Computer Vision subscription key to your environment variables.
if 'COMPUTER_VISION_SUBSCRIPTION_KEY' in os.environ:
    subscription_key = os.environ['COMPUTER_VISION_SUBSCRIPTION_KEY']
else:
    print("\nSet the COMPUTER_VISION_SUBSCRIPTION_KEY environment variable.\n**Restart your shell or IDE for changes to take effect.**")
    sys.exit()

if 'COMPUTER_VISION_ENDPOINT' in os.environ:
    endpoint = os.environ['COMPUTER_VISION_ENDPOINT']
else:
    print("\nSet the COMPUTER_VISION_ENDPOINT environment variable.\n**Restart your shell or IDE for changes to take effect.**")
    sys.exit()

headers = {
    # Request headers
    'Content-Type': 'application/json',
    'Ocp-Apim-Subscription-Key': subscription_key
}

body = {"url": "https://storage.googleapis.com/arunramkrish/Classic-Collection-Yes-Bank-p3.png"}
params = urllib.parse.urlencode({
})

try:
    endpoint = "finstinct-ocr.cognitiveservices.azure.com"
    conn = http.client.HTTPSConnection(endpoint)
    conn.request("POST", "/vision/v2.0/read/core/asyncBatchAnalyze?%s" % params, "{body}", headers)
    response = conn.getresponse()
    data = response.read()
    print(data)
    conn.close()
except Exception as e:
    print("[Errno {0}] {1}".format(e.errno, e.strerror))