"""
Package contains factory for various libraries available
"""