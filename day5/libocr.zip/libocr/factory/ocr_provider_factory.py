""""Factory for creating OCR Service Provider. For now each OCR service provider is mapped to a service key which
needs to be used to create respective OCR Provider """
import logging
from importlib import import_module
from libocr.ocr_provider import OcrProvider
from finstinct_config.loader import FinstinctConfig


# Fully qualified name (including package name) needs to be used
__ocr_modules = {
    "abbyy": "libocr.abbyy_impl.abbyy_ocr.AbbyyOcrProvider",
    "abbyyfre": "libocr.abbyyfre_impl.abbyyfre_ocr.AbbyyFreOcrProvider",
    "abbyyfreweb": "libocr.abbyyfreweb_impl.abbyyfreweb_ocr.AbbyyFreWebOcrProvider",
    "azure": "libocr.azure_impl.azure_vision.AzureOcrProvider",
    "tess": "libocr.tesseract_impl.tesseract_ocr.TesseractOcrProvider",
    "google": "libocr.google_impl.google_vision.GoogleOcrProvider"
}


def get_ocr_provider(ocr_svc_key):
    """
    @param ocr_svc_key: Identifies the OCR service to be created. Currently supported OCR services are "azure",
    "google", "tesseract"
    @raise ValueError in case the given key is invalid
    """
    mod_str = __ocr_modules.get(ocr_svc_key)
    if mod_str:
        m = get_class(mod_str)
        return m()
    else:
        raise ValueError()


# def get_class(kls):
#     return import_module(kls)
def get_class(kls):
    """
    Dynamically creates a python module for the given fully qualified string using __import__
    @param kls: Fully qualified name (including package name) until ClassName
    @raise ValueError: In case the module cannot be loaded
    """
    parts = kls.split('.')
    module = ".".join(parts[:-1])
    try:
        m = import_module(module)
        # for comp in parts[1:]:
        m = getattr(m, parts[-1])
        return m
    except ModuleNotFoundError:
        raise ValueError("Invalid package name " + module)
    except AttributeError:
        raise ValueError("Invalid class name " + parts[-1])


def avaiable_providers():
    return ["abbyy", "abbyyfre", "abbyyfreweb", "azure", "tess"]


def get_default_provider():
    try:
        finstinct_config = FinstinctConfig.get_config()
        default_ocr = finstinct_config.ocr_config.default_ocr_provider
        logging.info(f"Loaded {default_ocr} as default OCR")
        return default_ocr
    except Exception as e:
        logging.error("Unable to load FinStinct configuration", exc_info=True)
        raise e
    # try:
    #     if "Red Hat" in check_output(['hostnamectl']).decode():
    #         return "abbyyfre"
    #     else:
    #         return "abbyy"
    # except Exception as e:
    #     return "abbyy"


if __name__ == "__main__":
    # m = import_module("libocr.tesseract_impl.tesseract_ocr")
    # kls = getattr(m, "TesseractOcrProvider")
    # provider = kls()
    # print("Import modules")
    obj = get_ocr_provider("tess")
    assert isinstance(obj, OcrProvider)

    # negative testing
    # try:
    #     obj = get_ocr_provider("azurexcv")
    #     assert False
    # except ValueError:
    #     print("Got exception as expected")
    #     assert True