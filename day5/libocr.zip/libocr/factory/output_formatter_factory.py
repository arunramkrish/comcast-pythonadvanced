"""Factory for creating Output Formatter. For now each Output formatter is mapped to a service key which
needs to be used to create respective Output formatter """
from libocr.output_formatter import OutputFormatter

# Fully qualified name (including package name) needs to be used
__formatter_modules = {
    "pdf": "libocr.ocr_output_formatter.pdf.pdf_formatter.PdfOutputFormatter",
    "text_file": "libocr.ocr_output_formatter.text.text_file_formatter.TextFileFormatter",
    "console": "libocr.ocr_output_formatter.console.console_formatter.ConsoleFormatter",
    "dict": "libocr.ocr_output_formatter.dict.dict_formatter.DictOutputFormatter",
    "dom": "libocr.ocr_output_formatter.dom.dom_formatter.DomOutputFormatter"
}


def get_output_formatter(out_fmt_key):
    """
    @param out_fmt_key: Identifies the Output formatter to be created. Currently supported formats are "pdf",
    "text_file", "console"
    @raise ValueError in case the given key is invalid
    """
    mod_str = __formatter_modules.get(out_fmt_key)
    if mod_str:
        m = get_class(mod_str)
        return m()
    else:
        raise ValueError()


def get_class(kls):
    """
    Dynamically creates a python module for the given fully qualified string using __import__
    @param kls: Fully qualified name (including package name) until ClassName
    @raise ValueError: In case the module cannot be loaded
    """
    parts = kls.split('.')
    module = ".".join(parts[:-1])
    try:
        m = __import__(module)
        for comp in parts[1:]:
            m = getattr(m, comp)
        return m
    except ModuleNotFoundError:
        raise ValueError("Invalid package name " + module)
    except AttributeError:
        raise ValueError("Invalid class name " + comp)


if __name__ == "__main__":
    obj = get_output_formatter("pdf")
    assert isinstance(obj, OutputFormatter)

    # negative testing
    # try:
    #     obj = get_ocr_provider("azurexcv")
    #     assert False
    # except ValueError:
    #     print("Got exception as expected")
    #     assert True