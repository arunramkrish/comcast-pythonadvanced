from PIL import ImageFont


def get_text_size(text, font_size, font_name="arial.ttf"):
    # use a bitmap font
    # font = ImageFont.load(font_lib)

    # use a truetype font
    font_size = int(font_size)
    if font_name == None:
        font_name = "arial.ttf"
    font = ImageFont.truetype(font_name, font_size)

    return font.getsize(text)

if __name__ == "__main__":
    print(get_text_size("PIL is great", 8, "arial.ttf"))

