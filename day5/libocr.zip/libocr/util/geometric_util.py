import math


def bottom_left(bounding_box, width, height):
    new_bounding_box = [bounding_box[0], height - bounding_box[1], bounding_box[2], height - bounding_box[3],
                        bounding_box[4], height - bounding_box[5], bounding_box[6], height - bounding_box[7]]

    return new_bounding_box


origin_transformer = {
    "bottom-left": bottom_left
}


def transform_origin(transform_type, bounding_box, width, height):
    trans_fn = origin_transformer.get(transform_type)
    if trans_fn is None:
        raise NotImplementedError("Origin transform {} not supported".format(transform_type))
    return trans_fn(bounding_box, width, height)


def deskew_avg(current_box):
    # straightens top, bottom, left, right by avg the difference
    left = avg_num(current_box[0], current_box[6])
    right = avg_num(current_box[2], current_box[4])
    top = avg_num(current_box[1], current_box[3])
    bottom = avg_num(current_box[5], current_box[7])

    deskewed_box =[left, top, right, top, right, bottom, left, bottom]

    return deskewed_box

def avg_num(pt1, pt2):
    if pt1 == pt2:
        return pt1
    else:
        return math.floor((pt1 + pt2) / 2)


deskew_options = {
    "AVG": deskew_avg
}


def deskew_box(current_box, deskew_type):
    deskew_fn = deskew_options.get(deskew_type)
    if deskew_fn is None:
        raise NotImplementedError("Deskew fn {} not supported".format(deskew_type))
    return deskew_fn(current_box)
