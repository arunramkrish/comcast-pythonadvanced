import math
import numpy as np


def rotate_via_numpy(xy, radians):
    """Use numpy to build a rotation matrix and take the dot product."""
    x, y = xy
    c, s = np.cos(radians), np.sin(radians)
    j = np.matrix([[c, s], [-s, c]])
    m = np.dot(j, [x, y])

    return float(m.T[0]), float(m.T[1])


def rotate_origin_only(xy, radians):
    """Only rotate a point around the origin (0, 0)."""
    x, y = xy
    xx = x * math.cos(radians) + y * math.sin(radians)
    yy = -x * math.sin(radians) + y * math.cos(radians)

    return xx, yy


def rotate_around_point_lowperf(point, radians, origin=(0, 0)):
    """Rotate a point around a given point.

    I call this the "low performance" version since it's recalculating
    the same values more than once [cos(radians), sin(radians), x-ox, y-oy).
    It's more readable than the next function, though.
    """
    x, y = point
    ox, oy = origin

    qx = ox + math.cos(radians) * (x - ox) + math.sin(radians) * (y - oy)
    qy = oy + -math.sin(radians) * (x - ox) + math.cos(radians) * (y - oy)

    return qx, qy


def rotate_around_point_highperf(xy, radians, origin=(0, 0)):
    """Rotate a point around a given point.

    I call this the "high performance" version since we're caching some
    values that are needed >1 time. It's less readable than the previous
    function but it's faster.
    """
    x, y = xy
    offset_x, offset_y = origin
    adjusted_x = (x - offset_x)
    adjusted_y = (y - offset_y)
    cos_rad = math.cos(radians)
    sin_rad = math.sin(radians)
    qx = offset_x + cos_rad * adjusted_x + sin_rad * adjusted_y
    qy = offset_y + -sin_rad * adjusted_x + cos_rad * adjusted_y

    return qx, qy


def transform_to_origin(w, h, point):
    new_w = w/2
    new_h = h/2
    (x,y) = point
    new_point = (x - new_w, new_h - y)
    return new_point


def rotate_after_transform(w,h, point, angle):
    if angle == 0:
        return point
    # elif angle < 0:
    #     theta = math.radians(angle * -1)
    # else:
    # theta = math.radians(360 - angle)
    theta = math.radians(angle)
    point = transform_to_origin(w, h, point)
    (rotated_x, rotated_y) = rotate_origin_only(point, theta)

    new_w, new_h = rotate_width_height(w, h, angle)

    (trans_x, trans_y) = (new_w/2 - w/2, new_h/2 - h/2)
    # (trans_rotated_point_x, trans_rotated_point_y)  = (rotated_x + trans_x, rotated_y + trans_y)

    # abs_trans_rotated_point = (trans_rotated_point_x + new_w/2, new_h/2 - trans_rotated_point_y)
    abs_trans_rotated_point = (rotated_x + new_w / 2, new_h / 2 - rotated_y)
    return abs_trans_rotated_point


def rotate_width_height(w, h, angle):
    if angle == 0:
        return (w, h)
    # elif angle < 0:
    #     theta = math.radians(angle * -1)
    # else:
    theta = math.radians(angle)
    (x1, y1) = (w / 2 * -1, h / 2)
    (x2, y2) = (w / 2, h / 2)
    (x3, y3) = (w / 2, h / 2 * -1)
    (x4, y4) = (w / 2 * -1, h / 2 * -1)
    (new_x1, new_y1) = rotate_origin_only((x1, y1), theta)
    (new_x2, new_y2) = rotate_origin_only((x2, y2), theta)
    (new_x3, new_y3) = rotate_origin_only((x3, y3), theta)
    (new_x4, new_y4) = rotate_origin_only((x4, y4), theta)
    min_x = min(new_x1, new_x2, new_x3, new_x4)
    max_x = max(new_x1, new_x2, new_x3, new_x4)
    min_y = min(new_y1, new_y2, new_y3, new_y4)
    max_y = max(new_y1, new_y2, new_y3, new_y4)
    new_w = max_x - min_x
    new_h = max_y - min_y
    return new_w, new_h


def rotate_bounding_box(w, h, bounding_box, angle):
    (x1, y1) = (bounding_box[0], bounding_box[1])
    (x2, y2) = (bounding_box[2], bounding_box[3])
    (x3, y3) = (bounding_box[4], bounding_box[5])
    (x4, y4) = (bounding_box[6], bounding_box[7])

    new_bounding_box = []
    (x1, y1) = rotate_after_transform(w, h, (bounding_box[0], bounding_box[1]), angle)
    (x2, y2) = rotate_after_transform(w, h, (bounding_box[2], bounding_box[3]), angle)
    (x3, y3) = rotate_after_transform(w, h, (bounding_box[4], bounding_box[5]), angle)
    (x4, y4) = rotate_after_transform(w, h, (bounding_box[6], bounding_box[7]), angle)
    new_bounding_box.append(x1)
    new_bounding_box.append(y1)
    new_bounding_box.append(x2)
    new_bounding_box.append(y2)
    new_bounding_box.append(x3)
    new_bounding_box.append(y3)
    new_bounding_box.append(x4)
    new_bounding_box.append(y4)
    return new_bounding_box


def _main():
    # print( rotate_after_transform(462, 818, (414, 558), 270))
    # print(rotate_after_transform(827, 1169, (131,36), 90))
    # print(rotate_after_transform(827, 1169, (0, 0), 90))
    # print(rotate_width_height(827, 1169,-0.05))
    print(rotate_after_transform(850, 1100, (464, 833), -270))
    print(rotate_after_transform(850, 1100, (462, 744), -270))
    print(rotate_after_transform(850, 1100, (476, 743), -270))
    print(rotate_after_transform(850, 1100, (477, 836), -270))

    # theta = math.radians(270)
    # # point = (5, -11)
    # point = transform_to_origin(462, 818, (414, 558))
    # print(point)
    # print(rotate_via_numpy(point, theta))
    # print(rotate_origin_only(point, theta))
    # print(rotate_around_point_lowperf(point, theta))
    # print(rotate_around_point_highperf(point, theta))


if __name__ == '__main__':
    _main()