import logging
import pandas as pd
import numpy as np
import statistics
import sys


class StatUtil:
    @classmethod
    def frequency_distribution(cls, value_array):
        df = cls.dataframe_from_array(value_array)

        return df["val"].value_counts()

    @classmethod
    def dataframe_from_array(cls, value_array):
        index_array = [i for i in range(len(value_array))]
        value_array = value_array
        df = pd.DataFrame({
            "index": index_array,
            "val": value_array
        })
        return df

    @classmethod
    def quantiles(cls, value_array, q = 0.5, interpolation = "midpoint"):
        df = cls.dataframe_from_array(value_array)
        return df.quantile(q=q, interpolation = interpolation)

    @classmethod
    def get_outliers_using_zscore(cls, value_array, sd_threshold = 3):
        mean_1 = np.mean(value_array)
        std_1 = np.std(value_array)
        logging.debug("Mean: {}, SD: {}".format(mean_1, std_1))
        outliers = []
        for val in value_array:
            z_score = (val - mean_1)/std_1
            if np.abs(z_score) > sd_threshold:
                outliers.append(val)
        return outliers

    @classmethod
    def get_outliers_using_iqr(cls, value_array, mult = 1.5, threshold_iqr = 3):
        sorted_array = sorted(value_array)
        q1, q3 = np.percentile(sorted_array, [25,75])
        logging.debug("q1: {}, q3: {}".format(q1, q3))

        lower_bound = q1 - (mult * threshold_iqr)
        upper_bound = q3 + (mult * threshold_iqr)
        logging.debug("lower bound: {}, upper bound: {}".format(lower_bound, upper_bound))

        outliers = []
        for val in value_array:
            if val < lower_bound or val > upper_bound:
                outliers.append(val)
        return outliers

if __name__ == "__main__":
    logging.basicConfig(format='%(asctime)s:%(levelname)s:%(message)s', stream=sys.stdout, level=logging.DEBUG)

    values = [2, 28, 44, 27, 27, 33, 112, 27, 35, 27, 45, 70, 29, 34, 27, 25, 26, 44, 28, 27, 32]
    dis = StatUtil.frequency_distribution(values)
    logging.debug("Freq Dis " + str(dis))

    quantiles = StatUtil.quantiles(values, 0.75)
    logging.debug(quantiles)

    stat_quantiles = statistics.quantiles(values, n=5)
    logging.debug(stat_quantiles)

    logging.debug(StatUtil.get_outliers_using_iqr(values))

