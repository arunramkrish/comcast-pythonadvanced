# Pytest BDD Testing Example

# Requirements
* Python (3.12)

# How To Run the Unit Tests
To run the Unit Tests from the root of the repo, run
```bash
pytest -v
```
